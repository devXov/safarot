import similarity from 'similarity'
const threshold = 0.72
export async function before(m) {
    let id = m.chat
    if (!m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !m.text || !/اكتب.*hlir/i.test(m.quoted.text) || /.*hlir/i.test(m.text))
        return !0
    this.tebaklirik = this.tebaklirik || {}
    if (!(id in this.tebaklirik))
        return conn.reply(m.chat, '⚠️ *هذا السؤال قد انتهى.*', m)
    if (m.quoted.id == this.tebaklirik[id][0].id) {
        let isSurrender = /^((استسلام|surr?ender))$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebaklirik[id][3])
            delete this.tebaklirik[id]
            return conn.reply(m.chat, '*😔 استسلمت!*', m)
        }
        let json = JSON.parse(JSON.stringify(this.tebaklirik[id][1]))
        // m.reply(JSON.stringify(json, null, '\t'))
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
            global.db.data.users[m.sender].exp += this.tebaklirik[id][2]
            conn.reply(m.chat, `✅ *صحيح!*\n+${this.tebaklirik[id][2]} نقطة خبرة (XP)`, m)
            clearTimeout(this.tebaklirik[id][3])
            delete this.tebaklirik[id]
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold)
            m.reply(`🔍 *قريب جدًا!*`)
        else
            conn.reply(m.chat, `❌ *خطأ!*`, m)
    }
    return !0
}
export const exp = 0