import pkg from '@whiskeysockets/baileys';
import fs from 'fs';
import fetch from 'node-fetch';
import axios from 'axios';
import PhoneNumber from 'awesome-phonenumber';
import moment from 'moment-timezone';
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = pkg;

var handler = m => m;
handler.all = async function (m) {

global.getBuffer = async function getBuffer(url, options) {
  try {
    options ? options : {};
    var res = await axios({
      method: "get",
      url,
      headers: {
        'DNT': 1,
        'User-Agent': 'GoogleBot',
        'Upgrade-Insecure-Request': 1
      },
      ...options,
      responseType: 'arraybuffer'
    });
    return res.data;
  } catch (e) {
    console.log(`خطأ: ${e}`);
  }
};

let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
global.fotoperfil = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://qu.ax/QGAVS.jpg');
let api = await axios.get(`https://delirius-apiofc.vercel.app/tools/country?text=${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')}`);
let userNationalityData = api.data.result;
global.userNationality = userNationalityData ? `${userNationalityData.name} ${userNationalityData.emoji}` : 'غير معروف';
let user = global.db.data.users[who];
let bot = global.db.data.settings[this.user.jid];
let pushname = m.pushName || 'بدون اسم';
global.opts['gconly'] = true;

// تعريفات البوت
global.botcommandcount = bot.botcommandCount; // عدد الأوامر المنفذة.
global.creador = 'Wa.me/201023553649';
global.ofcbot = `${conn.user.jid.split('@')[0]}`;
global.asistencia = 'Wa.me/20115618853';
global.namechannel = 'قناة البوت الرئيسية';
global.namegrupo = 'مجموعة الدعم';
global.namecomu = 'مجتمع البوت';
global.colab1 = 'ميغيلون';
global.colab2 = 'ستيفن';
global.colab3 = 'دينو';

// معرفات القنوات
global.idchannel = '120363297635509525@newsletter';
global.canalIdM = ["120363367132202045@newsletter", "120363297635509525@newsletter"];
global.canalNombreM = ["قناة البوت الرئيسية", "قناة تجريبية"];
global.channelRD = await getRandomChannel();

// ردود الأوامر
global.rwait = '🕒';
global.done = '✅';
global.error = '✖️';

// الرموز التعبيرية
global.emoji = '🔥';
global.emoji2 = '💥';
global.emoji3 = '❤️‍🔥';
global.emoji4 = '🍭';
global.emojis = [emoji, emoji2, emoji3, emoji4].getRandom();

// رسائل انتظار
global.wait = '🕒 *انتظر لحظة، أنا بطيئة ...*';
global.waitt = '🕒 *انتظر لحظة، أنا بطيئة ...*';
global.waittt = '🕒 *انتظر لحظة، أنا بطيئة ...*';
global.waitttt = '🕒 *انتظر لحظة، أنا بطيئة ...*';

// روابط وقنوات
var canal = 'https://whatsapp.com/channel/0029VaeXAKJAjPXLKGuZSr46';  
let canal2 = 'https://whatsapp.com/channel/0029VaeXAKJAjPXLKGuZSr46';
var git = 'https://whatsapp.com/channel/0029VaeXAKJAjPXLKGuZSr46';
var youtube = 'https://whatsapp.com/channel/0029VaeXAKJAjPXLKGuZSr46';
var github = 'https://whatsapp.com/channel/0029VaeXAKJAjPXLKGuZSr46';
let correo = 'safrot272@gmail.com';

global.redes = [canal, canal2, git, youtube, github, correo].getRandom();

// صورة
let category = "imagen";
const db = './src/database/db.json';
const db_ = JSON.parse(fs.readFileSync(db));
const random = Math.floor(Math.random() * db_.links[category].length);
const randomlink = db_.links[category][random];
const response = await fetch(randomlink);
const rimg = await response.buffer();
global.icons = rimg;

// التحيات حسب الوقت
var ase = new Date();
var hour = ase.getHours();
switch (hour) {
  case 0:
  case 1:
  case 2:
    hour = 'مساء الخير 🌃';
    break;
  case 3:
  case 4:
  case 5:
  case 6:
    hour = 'صباح الخير 🌄';
    break;
  case 7:
  case 8:
  case 9:
  case 10:
  case 11:
  case 12:
    hour = 'نهارك سعيد 🌤';
    break;
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
    hour = 'مساء الخير 🌆';
    break;
  case 18:
  case 19:
  case 20:
  case 21:
  case 22:
  case 23:
    hour = 'مساء الخير 🌃';
    break;
}
global.saludo = hour;

// معرفات المستخدمين
global.nombre = conn.getName(m.sender);
global.taguser = '@' + m.sender.split("@s.whatsapp.net");
var more = String.fromCharCode(8206);
global.readMore = more.repeat(850);

// رسائل مزيفة
global.fkontak = { 
  key: { 
    participants: "0@s.whatsapp.net", 
    "remoteJid": "status@broadcast", 
    "fromMe": false, 
    "id": "Halo" 
  }, 
  "message": { 
    "contactMessage": { 
      "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD` 
    }
  }, 
  "participant": "0@s.whatsapp.net" 
};

// قناة عشوائية
global.rcanal = { 
  contextInfo: { 
    isForwarded: true, 
    forwardedNewsletterMessageInfo: { 
      newsletterJid: channelRD.id, 
      serverMessageId: 100, 
      newsletterName: channelRD.name, 
    }, 
    externalAdReply: { 
      showAdAttribution: true, 
      title: '♯ЅᗩFᏒOT', 
      body: '𝖘𝖆𝖋𝖗𝖔𝖙-𝖇𝖔𝖙', 
      mediaUrl: null, 
      description: null, 
      previewType: "PHOTO", 
      thumbnailUrl: icono, 
      sourceUrl: redes, 
      mediaType: 1, 
      renderLargerThumbnail: false 
    }, 
  }
};

export default handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

async function getRandomChannel() {
  let randomIndex = Math.floor(Math.random() * canalIdM.length);
  let id = canalIdM[randomIndex];
  let name = canalNombreM[randomIndex];
  return { id, name };
}