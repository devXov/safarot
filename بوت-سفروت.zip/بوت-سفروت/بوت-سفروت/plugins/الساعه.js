// بحقوق المطور ♯ЅᗩFᏒOT꙯ https://whatsapp.com/channel/0029VaxDFMOEVccHJn4fXD42
// https://wa.me/+201115618853@s.whatsapp.net/?text=💗

let handler = async (m, { conn }) => {
    try {
        const التاريخ = new Date();
        const خيارات = {
            hour: "numeric", 
            minute: "numeric", 
            second: "numeric", 
            timeZone: "Africa/Cairo", 
            hour12: true
        };

        const نص_الوقت = new Intl.DateTimeFormat("ar-EG", خيارات).format(التاريخ);

        const النص = `🕰 *\`『 الساعه دلوقتي 』\`* ${نص_الوقت}`;
        await m.reply(النص);
    } catch (e) {
        console.error(e);
        m.reply("حدث خطاء");
    }
};

handler.help = ['الساعه'];
handler.tags = ['♯ЅᗩFᏒOT꙯'];
handler.command = /^الساعه$/i;

export default handler;