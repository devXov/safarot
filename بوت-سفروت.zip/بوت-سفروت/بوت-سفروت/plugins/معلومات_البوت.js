import db from '../lib/database.js';
import ws from 'ws';
import { cpus as _cpus, totalmem, freemem, platform, hostname, version, release, arch } from 'os';
import os from 'os';
import moment from 'moment';
import speed from 'performance-now';
import { sizeFormatter } from 'human-readable';

let format = sizeFormatter({
    std: 'JEDEC',
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
});

const used = process.memoryUsage();

async function getSystemInfo() {
    let cpuInfo = os.cpus();
    let modeloCPU = cpuInfo && cpuInfo.length > 0 ? cpuInfo[0].model : 'المعالج غير متوفر';
    let espacioTotalDisco = 'غير متوفر';

    const data = {
        latencia: 'غير متوفر',
        plataforma: os.platform(),
        núcleosCPU: cpuInfo ? cpuInfo.length : 'غير متوفر',
        modeloCPU: modeloCPU,
        arquitecturaSistema: os.arch(),
        versiónSistema: os.release(),
        procesosActivos: os.loadavg()[0],
        porcentajeCPUUsada: 'غير متوفر',
        memory: humanFileSize(used.free, true, 1) + ' متاح من ' + humanFileSize(used.total, true, 1),
        ramUsada: 'غير متوفر',
        ramTotal: 'غير متوفر',
        ramLibre: 'غير متوفر',
        porcentajeRAMUsada: 'غير متوفر',
        espacioTotalDisco: espacioTotalDisco,
        tiempoActividad: 'غير متوفر',
        cargaPromedio: os.loadavg().map((avg, index) => `${index + 1} دقيقة: ${avg.toFixed(2)}.`).join('\n'),
        horaActual: new Date().toLocaleString(),
    };

    const startTime = Date.now();
    const endTime = Date.now();
    data.latencia = `${endTime - startTime} مللي ثانية`;

    return data;
}

let handler = async (m, { conn, usedPrefix }) => {
    let bot = global.db.data.settings[conn.user.jid];
    let _uptime = process.uptime() * 1000;
    let uptime = new Date(_uptime).toISOString().substr(11, 8);
    let totalreg = Object.keys(global.db.data.users).length;
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length;
    let totalbots = Object.keys(global.db.data.settings).length;
    let totalStats = Object.values(global.db.data.stats).reduce((total, stat) => total + stat.total, 0);
    const chats = Object.entries(conn.chats).filter(([id, data]) => id && data.isChats);
    let totalchats = Object.keys(global.db.data.chats).length;
    let totalf = Object.values(global.plugins).filter(v => v.help && v.tags).length;
    const groupsIn = chats.filter(([id]) => id.endsWith('@g.us'));
    let totaljadibot = [...new Set([...global.conns.filter((conn) => conn.user && conn.ws.socket && conn.ws.socket.readyState !== ws.CLOSED).map((conn) => conn)])];
    const totalUsers = totaljadibot.length;
    let timestamp = speed();
    let latensi = speed() - timestamp;
    const { restrict } = global.db.data.settings[conn.user.jid] || {}
    const { autoread } = global.opts    

getSystemInfo().then(async (data) => {
let teks = `*≡ معلومات البوت*

*المعلومات*
*▣ مجموع المجموعات:* ${groupsIn.length}
*▣ مجموعات منضمة:* ${groupsIn.length}
*▣ مجموعات غادرت:* ${groupsIn.length - groupsIn.length}
*▣ المحادثات الخاصة:* ${chats.length - groupsIn.length}
*▣ إجمالي المحادثات:* ${chats.length}
*▣ عدد البوتات الفرعية المتصلة:* ${totalUsers}
*▣ إجمالي الإضافات:* ${totalf}
*▣ السرعة:* ${latensi.toFixed(4)} مللي ثانية
*▣ وقت النشاط:* ${uptime}

*▣ الأوامر المنفذة:* ${toNum(totalStats)}/${totalStats}
*▣ مجموعات مسجلة:* ${toNum(totalchats)}/${totalchats}
*▣ المستخدمين المسجلين:* ${rtotalreg} من ${totalreg} مستخدم

*≡ معلومات السيرفر*
▣ *الخادم:* ${hostname()}
▣ *النظام الأساسي:* ${platform()}
▣ *عدد أنوية المعالج:* ${data.núcleosCPU} 
▣ *الذاكرة المستخدمة:* ${format(totalmem() - freemem())} من ${format(totalmem())}
▣ *مدة التشغيل:* ${toTime(os.uptime() * 1000)}`;

await conn.sendMessage(m.chat, {image: { url: "https://files.catbox.moe/dzycua.jpg" }, caption: teks, contextInfo: {externalAdReply: { title: `معلومات البوت`, sourceUrl: redes.getRandom(), mediaType: 1, showAdAttribution: true, thumbnailUrl: img1,
}}}, { quoted: m })});
}
handler.help = ['معلومات البوت'];
handler.tags = ['main'];
handler.command = /^(infobot|معلومات|معلومات_البوت|معلوماتالبوت)$/i;

export default handler;

function toNum(number) {
    if (number >= 1000 && number < 1000000) {
        return (number / 1000).toFixed(1) + 'k';
    } else if (number >= 1000000) {
        return (number / 1000000).toFixed(1) + 'M';
    } else if (number <= -1000 && number > -1000000) {
        return (number / 1000).toFixed(1) + 'k';
    } else if (number <= -1000000) {
        return (number / 1000000).toFixed(1) + 'M';
    } else {
        return number.toString();
    }
}

function humanFileSize(bytes) {
    const unidades = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const exponente = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, exponente)).toFixed(2)} ${unidades[exponente]}`;
}

function toTime(milliseconds) {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  return `${days} يوم، ${hours % 24} ساعة، ${minutes % 60} دقيقة، ${seconds % 60} ثانية`;
}