let handler = m => m;

handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat];
    let responses;

    if (/^جيت|انا جيت|جييت|جيييت|جييييت$/i.test(m.text)) {
        responses = [
            '*نورت💗*'
        ];
    } else if (/^يروحي$/i.test(m.text)) {
        responses = [
            '*قلب روحك😹💕*'
        ];
    } else if (/^صلي علي النبي|صلي ع النبي$/i.test(m.text)) {
        responses = [
            '*عليه افضل الصلاة والسلام🧚‍♂️🩵*',
            '*عليه الصلاة والسلام💜🧚‍♂️*',
            '*عليه الصلاة والسلام💜🦋*',
            '*عليه افضل الصلاة والسلام🕊🤍*'
        ];
    } else if (/^بحب سفروت$/i.test(m.text)) {
        responses = [
            '*ونا كمان بحبني😹💕*'
        ];
    } else if (/^يارب ديما$/i.test(m.text)) {
        responses = [
            '*ليا وليك💗*'
        ];
    } else if (/^عامل اي|ازيك$/i.test(m.text)) {
        responses = [
            '*تمام الحمد لله🙂*',
            '*احسن منك😹*',
            '*زي الفل💕*'
        ];
    } else if (/^انا مخنوق|انا زعلان$/i.test(m.text)) {
        responses = [
            '*ليه كده يسطا😹*'
        ];
    } else if (/^بموت فيك$/i.test(m.text)) {
        responses = [
            '*بعشقكك🥺💕*'
        ];
    } else if (/^فين البوت$/i.test(m.text)) {
        responses = [
            '*مافيش بوتات هنا😒*'
        ];
    } else if (/^ازاي$/i.test(m.text)) {
        responses = [
            '*زي السكر في الشاي😹🔪*'
        ];
    } else if (/^خخخ|خخخخ|خخخخخ|خخخخخخخ|خخ$/i.test(m.text)) {
        responses = [
            '*حاسب لتشرق😹*',
            '*خوخ ومنجه وسوق العبور😹*',
            '*حاسب لتبلع لسانك😹*'
        ];
    } else if (/^سلام$/i.test(m.text)) {
        responses = [
            '*باي😹*'
        ];
    } else if (/^حبيبي|حبيبي يا سفروت|حبيبي سفروت|سفروت حبيبي$/i.test(m.text)) {
        responses = [
            '*حبيبي🌚*',
            '*حبيبي مين🙂*',
            '*حبيبي ورجالي🙂*'
        ];
    } else if (/^كسمكو يولاد المتناكه|كسم الي هنا$/i.test(m.text)) {
        responses = [
            '*كسم امك المتناكه الشرموطه الي جبتك🔥*',
            '*كسمين امك يابن البوه يا ديوث يا عرص🔥*',
            '*كسم امك العاهره يااض🔥*',
            '*كسم امك يابن الزانيه🔥*'
        ];
    } else if (/^اسكت$/i.test(m.text)) {
        responses = [
            '*مين انت علشان تسكتني🦦*',
            '*اسكت انت🧸*'
        ];
    } else if (/^مين طلع سفروت|مين خرج سفروت$/i.test(m.text)) {
        responses = [
            'انا موجود اهو😹💜'
        ];
    } else if (/^عايز اعيط|عيزه اعيط$/i.test(m.text)) {
        responses = [
            '*ليه كده😹*'
        ];
    } else if (/^انا جعان$/i.test(m.text)) {
        responses = [
            '*طب ونا مالي😹🧸*'
        ];
    } else if (/^سفروت جوزتي|سفروت جوزني$/i.test(m.text)) {
        responses = [
            '*غطيها طب😹*',
            '*شوف وهتلي معاك😹😹*'
        ];
    } else if (/^بوسه|محح|بوسني$/i.test(m.text)) {
        responses = [
            '*موووووه💋*'
        ];
    } else if (/^متيجي$/i.test(m.text)) {
        responses = [
            '*مليش ف الخشن😂🏌*',
            '*متيجي انت💋😂*'
        ];
    } else if (/^بكرهك|بكرهكو|بككرهك$/i.test(m.text)) {
        responses = [
            '*انا اصلا محبتكيش😹💣*'
        ];
    } else if (/^بضان|بضاني|بضنتني$/i.test(m.text)) {
        responses = [
            '*مافيش غيرك هنا بضان😹🦦*',
            '*انت البضان نفسهاا😹🦦*'
        ];
    } else if (/^كسم سفروت|كسمك يسفروت$/i.test(m.text)) {
        responses = [
            '*كسمين امك المتناكه الي جبتك🫵🏻*',
            '*سفروت نايك امك وانت معرص🫵🏻*'
        ];
    } else if (/^تصبح على خير$/i.test(m.text)) {
        responses = [
            '*وانت من اهله🧚🏻‍♂️*',
            '*وانت طيب🧚🏻‍♂️*'
        ];
    } else if (/^مين ضفني|مين الي جبني هنا$/i.test(m.text)) {
        responses = [
            '*ضور عليه بقا😹🦦*',
            '*معرفش🧸*'
        ];
    } else if (/^ربنا معاك$/i.test(m.text)) {
        responses = [
            '*ومعاك يحب😹*',
            '*تثلم يحب😹*'
        ];
    } else if (/^🙂|🙂🙂$/i.test(m.text)) {
        responses = [
            '*معلش الصدمه وحشه🙂*',
            '*حقك عليا🙂*',
            '*اتصدم🙂*',
            '*مصدوم🙂*',
            '*صدمني🙂*',
            '*🙂*',
            '*🙂🙂*'
        ];
    } else if (/^وحشني$/i.test(m.text)) {
        responses = [
            '*وانت اكتر😍*',
            '*وحشني طلتك😹*'
        ];
    } else if (/^ايه الاخبار؟$/i.test(m.text)) {
        responses = [
            '*كلو تمام الحمد لله🧚🏻‍♂️*',
            '*ماشي الحال وانت؟*'
        ];
    } else if (/^سافل$/i.test(m.text)) {
        responses = [
            '*ايوه 🙂*'
        ];
    } else if (/^انا مبضون|انا ابضنت$/i.test(m.text)) {
        responses = [
            '*ونا كمان🙂*',
            '*ونا اوي🙂*'
        ];
    } else if (/^حاسب$/i.test(m.text)) {
        responses = [
            '*ممعيش فكه🦦*',
            '*حاسب انت🦦*'
        ];
    } else if (/^بعشقك|بعشقكك$/i.test(m.text)) {
        responses = [
            '*بادمنك💋☺️*',
            '*يوغتييي😹🙂*'
        ];
    } else if (/^فين الناس؟$/i.test(m.text)) {
        responses = [
            '*مش عارف والله*',
            '*يمكن نايمين*'
        ];
    } else if (/^قلبي$/i.test(m.text)) {
        responses = [
            '*قلب قلبك🌚*',
            '*قلبي💗*'
        ];
    } else if (/^لف$/i.test(m.text)) {
        responses = [
            '*لف انت😼🔥*'
        ];
    } else if (/^بوت عرص$/i.test(m.text)) {
        responses = [
            '*امك لبسه استارز☺️*'
        ];
    } else if (/^بوت متناك|بوت متناكك$/i.test(m.text)) {
        responses = [
            '*زبي اداك علي قفاك😁*'
        ];
    } else if (/^بوت خول$/i.test(m.text)) {
        responses = [
            '*حد قلك اني شبهك يكسمك🐤*'
        ];
    } else if (/^كسم البوت$/i.test(m.text)) {
        responses = [
            '*علي كسمك😁*'
        ];
    } else if (/^بحب البوت$/i.test(m.text)) {
        responses = [
            '*ونا كمان بحبك☺️🥂*'
        ];
    }

    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);
        conn.reply(m.chat, responses[randomIndex], m);
    }
    return !0;
};

export default handler;