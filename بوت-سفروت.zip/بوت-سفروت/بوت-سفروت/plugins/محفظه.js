import axios from 'axios';

let handler = async (m, { conn, usedPrefix }) => {
    let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
    let user = global.db.data.users[who];
    let username = conn.getName(who);

    if (!(who in global.db.data.users)) throw `🟨 المستخدم مش موجود في قاعدة البيانات بتاعتي :c`;

    const line = '━━━━━━━━━━━━━━━━━';
    const spacer = '                   ';

    const walletMessage = `
${line}
👛 *محفظة ${username}* 👛
${line}

💰 *الذهب*: ${user.credit} 💰

${line}
📊 *أحدث المعاملات* 📊
(قريباً...)
${line}

🛒 *أوامر الاقتصاد* 
- *${usedPrefix}daily*: اجمع مكافأتك اليومية.
- *${usedPrefix}work*: اشتغل عشان تكسب دهب.
- *${usedPrefix}حول [مستخدم] [مبلغ]*: حول ذهب لشخص تاني.

${line}
🌟 *خيارات أخرى* 🌟
${spacer}- *${usedPrefix}profile*: اعرض ملفك الشخصي.

📜 محتاج مساعدة؟ جرب ${usedPrefix}help
${line}
`;

    try {
        const imgUrl = 'https://files.catbox.moe/y09nuh.jpg';
        const responseImg = await axios.get(imgUrl, { responseType: 'arraybuffer' });
        await conn.sendFile(m.chat, responseImg.data, "thumbnail.jpg", walletMessage, m);
    } catch (e) {
        await conn.reply(m.chat, walletMessage, m);
    }
}

handler.help = ['محفظة'];
handler.tags = ['الاقتصاد'];
handler.command = ['محفظة','دهب', 'المحفظه'];

handler.group = true;

export default handler;