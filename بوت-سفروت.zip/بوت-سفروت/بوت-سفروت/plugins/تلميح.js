let handler = async (m, { conn }) => {
    conn.tebaklogo = conn.tebaklogo || {}
    let id = m.chat
    if (!(id in conn.tebaklogo)) throw '⚠️ *لا توجد لعبة تخمين الشعار جارية حاليًا في هذا المحادثة.*'
    let json = conn.tebaklogo[id][1]
    conn.reply(m.chat, '```' + json.hasil.data.jawaban.replace(/[AIUEOaiueo]/ig, '_') + '```', m)
}
handler.command = /^hlog$/i

export default handler