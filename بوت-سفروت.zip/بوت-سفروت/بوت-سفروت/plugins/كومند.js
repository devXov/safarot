let handler = async (m, { conn }) => {
  // تصنيف الإضافات حسب العلامات
  let plugins = Object.entries(global.plugins).filter(
    ([name, plugin]) => plugin.help && plugin.tags && plugin.command
  );

  // إنشاء قائمة لكل نوع
  let categorizedPlugins = {};

  for (let [fileName, plugin] of plugins) {
    for (let tag of plugin.tags) {
      if (!categorizedPlugins[tag]) categorizedPlugins[tag] = [];
      categorizedPlugins[tag].push({
        file: fileName,
        help: plugin.help,
        command: plugin.command,
      });
    }
  }

  // بناء النص لإرساله
  let message = '*📜 قائمة الأوامر حسب التصنيف:*\n\n';
  for (let [tag, items] of Object.entries(categorizedPlugins)) {
    let index = 1;
    message += `\n\n*• ${tag.toUpperCase()}*\n\n`;
    for (let { file, help, command } of items) {
      
      message += `\n- [${index}] *الملف:* ${file}\n  *الأوامر:* ${command}\n*الإشارة:* ${help.join(', ')}\n`;
      index = index + 1;
    }
    message += '\n';
  }

  // إرسال الرسالة
  await m.reply(message);
};

handler.help = ['كومند'];
handler.tags = ['معلومات'];
handler.command = /^(كومند)$/i;

export default handler;