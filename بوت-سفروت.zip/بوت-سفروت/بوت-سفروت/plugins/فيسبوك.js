import { igdl } from 'ruhend-scraper'

const handler = async (m, { text, conn, args, usedPrefix, command }) => {
    if (!args[0]) {
        return conn.reply(m.chat, '🧚🏻‍♂️ *يرجى إدخال رابط من فيسبوك*', m, rcanal)
    }
    let res
    try {
        conn.reply(m.chat, `🕒 *جاري تحميل الفيديو من فيسبوك...*`, m, {
            contextInfo: { 
                externalAdReply: { 
                    mediaUrl: null, 
                    mediaType: 1, 
                    showAdAttribution: true,
                    title: '♯ЅᗩFᏒOT꙯',
                    body: '𝐒𝐀𝐅𝐑𝐎𝐓-𝐁𝐎𝐓',
                    previewType: 0, 
                    thumbnail: logo8,
                    sourceUrl: channel 
                }
            }
        })
        await m.react(rwait)
        res = await igdl(args[0])
    } catch {
        await m.react(error)
        return conn.reply(m.chat, '🚩 *حدث خطأ أثناء جلب البيانات. تحقق من الرابط.*', m, fake)
    }
    let result = res.data
    if (!result || result.length === 0) {
        return conn.reply(m.chat, '🚩 *لم يتم العثور على نتائج.*', m, fake)
    }
    let data
    try {
        await m.react(rwait)
        data = result.find(i => i.resolution === "720p (HD)") || result.find(i => i.resolution === "360p (SD)")
    } catch {
        await m.react(error)
        return conn.reply(m.chat, '🚩 *حدث خطأ أثناء معالجة البيانات.*', m, rcanal)
    }
    if (!data) {
        return conn.reply(m.chat, '🚩 *لم يتم العثور على دقة مناسبة.*', m, rcanal)
    }
    let video = data.url
    try {
        await m.react(rwait)
        await conn.sendMessage(m.chat, { 
            video: { url: video }, 
            caption: '> *تم تحميل الفيديو*\n' + textbot, 
            fileName: 'fb.mp4', 
            mimetype: 'video/mp4' 
        }, { quoted: fkontak })
        await m.react(done)
    } catch {
        await m.react(error)
        return conn.reply(m.chat, '🚩 *حدث خطأ أثناء إرسال الفيديو.*', m, rcanal)
    }
}

handler.help = ['فيسبوك', 'فيس']
handler.tags = ['تنزيل']
handler.command = ['فيسبوك', 'فيس']

export default handler