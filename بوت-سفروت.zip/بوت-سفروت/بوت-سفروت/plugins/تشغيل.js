

const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = (await import('@whiskeysockets/baileys')).default;
import yts from 'yt-search';
import axios from 'axios';

let handler = async (m, { conn, usedPrefix, command, text }) => {
   if (!text) return m.reply(`*\`『 اكتب الي عايز تشغلو الامر 🧚🏻‍♂️ 』\`*`);
   
   try {
        await m.react('🕓');
      let search = await yts(text);
      let video = search.all[0];
      let linkyt = video.url;
      let teksnya = `العنوان: *${video.title}*\nالمشاهدات: *${video.views}*\nالمدة: *${video.timestamp}*\nتم الرفع: *${video.ago}*\nالرابط: *${linkyt}*`;

      const { imageMessage } = await prepareWAMessageMedia(
            {
                image: { url: video.thumbnail }
            },
            { upload: conn.waUploadToServer }
        );

        const messageContent = {
            buttonsMessage: {
                contentText: teksnya,
                footerText: global.namabotbot,
                buttons: [
                    {
                        buttonId: `.فيديو ${linkyt}`,
                        buttonText: { displayText: 'الفيديو 🎬' },
                        type: 1
                    },
                    {
                        buttonId: `.اغنيه ${linkyt}`,
                        buttonText: { displayText: 'الصوت 🎧' },
                        type: 1
                    }
                ],
                headerType: 4,
                imageMessage: imageMessage,
            }
        };

        const message = generateWAMessageFromContent(
            m.chat,
            {
                ephemeralMessage: {
                    message: messageContent
                }
            },
            { userJid: conn.user.id }
        );

        await conn.relayMessage(m.chat, message.message, { messageId: message.key.id });
    } catch (error) {
        console.error("فشل إرسال الرسالة بزر مع الصورة:", error);
        await conn.sendMessage(m.chat, { text: "عذرًا، حدث خطأ أثناء إرسال الرسالة." });
    }
};

handler.help = ['play'].map(v => v + ' <بحث>');
handler.tags = ['تنزيل'];
handler.command = /^(تشغيل|ytplay)$/i;
handler.limit = true;

export default handler;