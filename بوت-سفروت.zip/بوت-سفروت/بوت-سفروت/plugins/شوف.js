import fs from 'fs';
import fetch from 'node-fetch';
import FormData from 'form-data';

let handler = async (message, { text, conn }) => {
  let userQuestion = text || "اشرح لي هذه الصورة";

  if (!message.quoted) {
    throw "> *\`『 اعمل ريب ع الصوره او الملصق 🧚🏻‍♂️ 』\`*";
  }

  try {
    let targetMessage = message.quoted;

    if (!((targetMessage.msg || targetMessage).mimetype || targetMessage.mediaType || "").startsWith('image') && !/sticker|document/.test((targetMessage.msg || targetMessage).mimetype || targetMessage.mediaType || "")) {
      return message.reply("> *\`『 اعمل ريب ع الصوره او الملصق🧚🏻‍♂️ 』\`*");
    }

    await conn.sendMessage(message.chat, { react: { text: "🧚🏻‍♂️", key: message.key } });

    let imageUrl = '';
    if (/image|sticker|document/.test((targetMessage.msg || targetMessage).mimetype || targetMessage.mediaType || "")) {
      let media = await targetMessage.download(true);
      let data = await uploadFile(media);
      if (!data || !data.files || !data.files[0] || !data.files[0].url) {
        console.error("Failed to upload image:", data);
        throw "تعذر رفع الصورة.";
      }
      imageUrl = data.files[0].url;
    }

    const encodedText = encodeURIComponent(userQuestion);
    const apiUrl = `https://ai.xterm.codes/api/text2speech/bella?text=${encodedText}&img=${imageUrl}`;

    console.log("API URL:", apiUrl); // لتسجيل الرابط المستخدم
    conn.sendPresenceUpdate("composing", message.chat);

    const response = await fetch(apiUrl);
    if (!response.ok) {
      console.error("API Error:", await response.text());
      throw "خطأ في استجابة الخادم.";
    }

    const jsonResponse = await response.json();
    if (!jsonResponse || !jsonResponse.result) {
      console.error("Invalid API Response:", jsonResponse);
      throw "تعذر معالجة الرد.";
    }

    let result = jsonResponse.result.trim().replace(/[.,]$/, "");
    message.reply(`*${result}*`);
  } catch (error) {
    console.error("Error:", error);
    message.reply("*حدث خطأ، برجاء المحاولة لاحقًا.*");
  }
};

handler.help = ["شرح"];
handler.tags = ["he"];
handler.command = ["شرح"];

export default handler;

async function uploadFile(path) {
  try {
    let form = new FormData();
    form.append('files[]', fs.createReadStream(path));
    let res = await (await fetch('https://uguu.se/upload.php', {
      method: 'post',
      headers: {
        ...form.getHeaders()
      },
      body: form
    })).json();
    await fs.promises.unlink(path); 
    return res;
  } catch (error) {
    console.error("Upload Error:", error);
    throw "فشل رفع الملف.";
  }
}