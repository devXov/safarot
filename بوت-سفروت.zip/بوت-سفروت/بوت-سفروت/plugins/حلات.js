import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
    let pies = dir; // تأكد من تعريف مصفوفة pies
    let url = pies[Math.floor(Math.random() * pies.length)];

    // تأكد من أن url ليست فارغة
    if (url) {
        conn.sendButton(m.chat, `استوري رايق زيك🧚🏻‍♂️`, author, url, [], m); // بدون أزرار إضافية
    } else {
        console.error("رابط الفيديو غير متوفر");
    }
}

handler.help = ['ايدت-انمي']
handler.tags = ['internet']
handler.command = /^(استوري-سفروت|سفروت-استوري|حلات|حلات-وتس|حلات_وتس|حلات وتس)$/
handler.exp = 50
handler.level = 0
export default handler

const dir = [
    'https://files.catbox.moe/tijtvq.mp4',
    'https://files.catbox.moe/h4mq6j.mp4',
    'https://files.catbox.moe/e027bl.mp4',
    'https://files.catbox.moe/4rahfk.mp4',
    'https://files.catbox.moe/m4gxa0.mp4',
    'https://files.catbox.moe/qds5n6.mp4',
    'https://files.catbox.moe/0qmze9.mp4',
    'https://files.catbox.moe/cld0uc.mp4',
    'https://files.catbox.moe/uz5vc8.mp4',
    'https://files.catbox.moe/cbexyp.mp4',
    'https://files.catbox.moe/bidh2r.mp4',
    'https://files.catbox.moe/4fhlok.mp4',
    'https://files.catbox.moe/m7dy1z.mp4',
    'https://files.catbox.moe/bffvd6.mp4',
    'https://files.catbox.moe/ewv3h1.mp4',
    'https://files.catbox.moe/cf9ccd.mp4',
    'https://files.catbox.moe/ofmzuy.mp4',
    'https://files.catbox.moe/2ilqdt.mp4',
    'https://files.catbox.moe/u0x4bt.mp4',
    'https://files.catbox.moe/ognqxa.mp4',
    'https://files.catbox.moe/cbht2k.mp4',
    'https://files.catbox.moe/rj12r7.mp4',
    'https://files.catbox.moe/k5kj0a.mp4',
    'https://files.catbox.moe/1l1thc.mp4',
    'https://files.catbox.moe/381hsv.mp4',
    'https://files.catbox.moe/ofpi4g.mp4',
    'https://files.catbox.moe/o8kil0.mp4',
    'https://files.catbox.moe/l64otl.mp4',
    'https://files.catbox.moe/hajwps.mp4',
    'https://files.catbox.moe/gbm73d.mp4',
    'https://files.catbox.moe/hajwps.mp4',
    'https://files.catbox.moe/gpdzto.mp4',
    'https://files.catbox.moe/d5pv3s.mp4',
    'https://files.catbox.moe/5xydao.mp4',
    'https://files.catbox.moe/u47n9r.mp4',
    'https://files.catbox.moe/5yq87d.mp4',
    'https://files.catbox.moe/v68hg2.mp4',
    'https://files.catbox.moe/dcv9ow.mp4',
    'https://files.catbox.moe/7p9t50.mp4',
    'https://files.catbox.moe/4lpx84.mp4',
    'https://files.catbox.moe/giifyz.mp4',
    'https://files.catbox.moe/fe94aj.mp4',
    'https://files.catbox.moe/2ia4ed.mp4',
    'https://files.catbox.moe/0ahhy0.mp4',
    'https://files.catbox.moe/u78ige.mp4',
    'https://files.catbox.moe/nb9rkc.mp4',
    'https://files.catbox.moe/e9orl3.mp4',
    'https://files.catbox.moe/zgc49c.mp4',
    'https://files.catbox.moe/an31on.mp4',
    'https://files.catbox.moe/7du72j.mp4',
    'https://files.catbox.moe/d2o06s.mp4',
    'https://files.catbox.moe/pfg2zc.mp4',
    'https://files.catbox.moe/wg36vz.mp4',
    'https://files.catbox.moe/bwrdo3.mp4',
    'https://files.catbox.moe/5asxvu.mp4',
    'https://files.catbox.moe/xoya29.mp4',
    'https://files.catbox.moe/slcmki.mp4',
    'https://files.catbox.moe/c9rih0.mp4',
    'https://files.catbox.moe/dhepok.mp4',
    'https://files.catbox.moe/5v4tnw.mp4',
    'https://files.catbox.moe/ko9r5b.mp4',
    'https://files.catbox.moe/4cx8ui.mp4',
    'https://files.catbox.moe/do68ic.mp4',
    'https://files.catbox.moe/3z0w8i.mp4',
    'https://files.catbox.moe/gyp317.mp4',
    'https://files.catbox.moe/s1ushr.mp4',
    'https://files.catbox.moe/c3e6rl.mp4',
    'https://files.catbox.moe/ushonl.mp4',
    'https://files.catbox.moe/pk0a7t.mp4',
    'https://files.catbox.moe/e60uwt.mp4',
    'https://files.catbox.moe/vmls9q.mp4',
    'https://files.catbox.moe/gcbm3d.mp4',
    'https://files.catbox.moe/p8v9et.mp4',
    'https://files.catbox.moe/oglx3x.mp4',
    'https://files.catbox.moe/kxm0qs.mp4',
    'https://files.catbox.moe/kr98o5.mp4',
    'https://files.catbox.moe/5kdd25.mp4',
    'https://files.catbox.moe/191bpx.mp4',
    'https://files.catbox.moe/b9oipt.mp4',
    'https://files.catbox.moe/kjxko2.mp4',
    'https://files.catbox.moe/lo3knh.mp4',
    'https://files.catbox.moe/jtiarq.mp4',
    'https://files.catbox.moe/8vpp9b.mp4',
    'https://files.catbox.moe/j94uqd.mp4',
    'https://files.catbox.moe/fg24xu.mp4',
    'https://files.catbox.moe/vertf0.mp4',
    'https://files.catbox.moe/4yv5es.mp4'
];