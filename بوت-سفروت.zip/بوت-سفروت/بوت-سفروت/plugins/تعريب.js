import translate from '@vitalets/google-translate-api'
const defaultLang = 'ar'  // تحديد اللغة الافتراضية إلى العربية
const tld = 'cn'

let handler = async (m, { args, usedPrefix, command }) => {
    let err = `> *\`『 ريب ع الي عايز تعربو 🧚🏻‍♂️ 』\`*`.trim()

    let text = args.join(' ')
    if (!text && m.quoted && m.quoted.text) text = m.quoted.text

    try {
        let result = await translate(text, { to: defaultLang, autoCorrect: true }).catch(_ => null)
        m.reply(result.text)
    } catch (e) {
        throw err
    } 
}

handler.help = ['تعريب']
handler.tags = ['tools']
handler.command = ['تعريب']

export default handler