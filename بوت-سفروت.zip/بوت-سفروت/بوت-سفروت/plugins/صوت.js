let handler = m => m;

handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat];
    global.db.data.users[m.sender].money += 50;
    global.db.data.users[m.sender].exp += 50;

    if (/ملك القراصنه$/i.test(m.text) && chat.audios) {  
        if (!chat.audios && m.isGroup) throw 0;    
        let vn = './media/luffy.itashi.mp3';
        await this.sendPresenceUpdate('recording', m.chat);   
        await this.sendFile(m.chat, vn, 'error.mp3', null, m, true, {type: 'audioMessage', ptt: true});
    }

    if (/^لوفي|ملك القراصنه|لووفي$/i.test(m.text) && chat.audios) {  
        if (!chat.audios && m.isGroup) throw 0;    
        let vn = './media/luffy.itashi.mp3';
        await this.sendPresenceUpdate('recording', m.chat);   
        await this.sendFile(m.chat, vn, 'error.mp3', null, m, true, {type: 'audioMessage', ptt: true});
    }
};

export default handler;
