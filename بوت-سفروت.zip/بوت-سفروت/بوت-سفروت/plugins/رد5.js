let handler = m => m;

handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat];
    let responses;

    if (/^سفروت يكلب|سفروت كلب|الكلب سفروت|سفروت كلبي|سفروت كلبو|كلبي سفروت$/i.test(m.text)) {
        responses = ['*كسمك يبن المره البوه هنيكك*', '*ابوك الكلب  يكسمك*'];
    } else if (/^اسمك الريل|نيمك الريل|نيمك الحقيقي|اسمك الحقيقي$/i.test(m.text)) {
        responses = ['*ابراهيم باين🙂*', '*ابرهيم😍*', '*ابراهيم يحب🙂*'];
    } else if (/^المطور|مين المطور|الصانع$/i.test(m.text)) { 
        responses = ['*مطوري @01115618853 🧚🏻‍♂️*'];
    } else if (/^ممكن نتعرف|نتعرف$/i.test(m.text)) {
        responses = ['*لا 🙂*', '*ينرم😹*', '*🙂🙂*'];
    } else if (/^كلموني|اتكلمو|كلمووني$/i.test(m.text)) {
        responses = ['*لا🙂*', '*مش فاضي😹*', '*كلموني انا😹*'];
    } else if (/^سفروت يعلق$/i.test(m.text)) {
        responses = ['*بترول🙂*', '*.انطر*', '*شيفني شبهك🙂*'];
    } else if (/^ملكش دعوه|ملكش دعوة$/i.test(m.text)) {
        responses = ['*كرت دعوه😹*'];
    } else if (/^ملكش في$/i.test(m.text)) {
        responses = ['*شد وجمد في😹*'];
    } else if (/^يكوتي$/i.test(m.text)) {
        responses = ['*قلب كوتك😍😹*'];
    } else if (/^هعيط|بعيط$/i.test(m.text)) {
        responses = ['*معلش يروحي😹🙂*', '*احسن😹*', 'ونا مالي🙂😹*', '*ونا كمان🙂*'];
    } else if (/^عااه|عاااه|عااااه|عااااا|عااااااه|عاااااااه|عاااااااااه$/i.test(m.text)) {
        responses = ['*عاااااه😹*'];
    } else if (/^مبروك|مبروق|مبروووك|مبرووووووك$/i.test(m.text)) {
        responses = ['*الله يبارك فيك😹*'];
    } else if (/^اخرص$/i.test(m.text)) {
        responses = ['*اخرص انت😒*', '*لا😒*'];
    } else if (/^كوزي|كووزي$/i.test(m.text)) {
        responses = ['*قلبي🌚*', '*بحبق💋🥂*', '*قلب كوزك😹💋*', '*🙂🙂*'];
    } else if (/^حبق|بحبق$/i.test(m.text)) {
        responses = ['*بموت فيك🌚💋*', '*بحبق اكتر🌚💗*', '*موور🌚💗*'];
    } else if (/^كيفك|اخبارك$/i.test(m.text)) {
        responses = ['*تمم تمم💗*', '*الحمد لله💗*', '*فل يكوتي💗*', '*بخير وانت💗*'];
    } else if (/^نو ريب$/i.test(m.text)) {
        responses = ['*يمحني😹*', '*يمحني🙂*'];
    } else if (/^ماشي|ماثي$/i.test(m.text)) {
        responses = ['*مكسح🙂*', '*بيعرج😹*'];
    } else if (/^طيب|تيب$/i.test(m.text)) {
        responses = ['*علي اي🙂*', '*خلصا*', '*تيب*'];
    }

    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);
        this.reply(m.chat, responses[randomIndex], m); // Replace conn with this
    }

    return true;
};

export default handler;