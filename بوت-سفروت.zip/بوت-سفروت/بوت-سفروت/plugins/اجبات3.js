import fetch from 'node-fetch'
let timeout = 120000
let poin = 4999
let handler = async (m, {
    conn,
    command,
    usedPrefix
}) => {
    conn.tebaklogo = conn.tebaklogo || {}
    let id = m.chat
    if (id in conn.tebaklogo) {
        conn.reply(m.chat, '⚠️ *يوجد سؤال لم تتم الإجابة عليه في هذه المحادثة.*', conn.tebaklogo[id][0])
        throw false
    }
    let res = await fetch(`https://raw.githubusercontent.com/orderku/db/main/dbbot/game/tebakapp.json`)
    let src = await res.json()
    let Apps = src[Math.floor(Math.random() * src.length)]
    let json = {
        hasil: Apps
    }
    let caption = `*${command.toUpperCase()}*
ما هو هذا الشعار؟

⏳ الوقت: *${(timeout / 1000).toFixed(2)} ثانية*
💡 اكتب ${usedPrefix}hlog للحصول على تلميح
🎁 المكافأة: ${poin} نقطة خبرة (XP)
    `.trim()
    conn.tebaklogo[id] = [
        await conn.sendFile(m.chat, json.hasil.data.image, '', caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.tebaklogo[id]) {
                conn.reply(m.chat, `⏰ *انتهى الوقت!*\nالإجابة الصحيحة هي: *${json.hasil.data.jawaban}*`, conn.tebaklogo[id][0])
                delete conn.tebaklogo[id]
            }
        }, timeout)
    ]
}
handler.help = ['tebaklogo']
handler.tags = ['game']
handler.command = /^tebaklogo/i

export default handler

const buttons = [
    ['تلميح', '/hlog'],
    ['استسلام', 'menyerah']
]