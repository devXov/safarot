const handler = async (m, {command}) => {
  
  switch (command) {
  
  case 'اكتم':
  global.db.data.chats[m.chat].isBanned = true;
  m.reply('*`❲🔒❳` تم كتم المحادثه*\n\n*`⛊ هذه المحادثة ليس لها الأذن لاستعمالي الآن`*');
  break;
  
  case 'فك_الكتم':
  global.db.data.chats[m.chat].isBanned = false;
  m.reply('*`❲🔓❳` تم الغاء كتم المحادثه*\n\n*`⛊ هذه المحادثة لها الأذن لاستعمالي الآن`*');
  break;
  
  }
};
handler.help = ['banchat'];
handler.tags = ['owner'];
handler.command = ['اكتم', 'فك_الكتم'];
handler.rowner = true;
export default handler;