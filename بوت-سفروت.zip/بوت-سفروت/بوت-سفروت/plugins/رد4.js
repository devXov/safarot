let handler = m => m;

handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat];
    let responses;

    if (/^الحمد لله|الحمدلله|حمدلله$/i.test(m.text)) {
        responses = ['*ديماا يارب*'];
    } else if (/^اجوزني$/i.test(m.text)) {
        responses = ['*اجوز مين😹😹*', '*امشي من هنا😹*', '*اجوزي مطوري😹💗*'];
    } else if (/^جوزي|قوزي|جوزي اهو|ده جوزي$/i.test(m.text)) { 
        responses = ['*مراتي حببتي😹💗*', '*مراتي الاوله😹💗*', '*انا مطلقك اصلا😹💗*', '*مراتي التانيه😹💗*', '*مراتي التالته😹💗*', '*مراتي الرابعه😹💗*'];
    } else if (/^قلبي قلبي|قلب قلبك$/i.test(m.text)) {
        responses = ['*حبيبي😻*', '*قلبي🌚*'];
    } else if (/^هجوزك$/i.test(m.text)) {
        responses = ['*لا مليش فلخشن😹💗*', '*هفكر💗😹*', '*اقتلي امك ونزلي💗😹*'];
    } else if (/^بتكسفني|كسفني$/i.test(m.text)) {
        responses = ['*غصبن عني🙂*', '*لا🙂*', '*اها😹🙂*'];
    } else if (/^هكسفك$/i.test(m.text)) {
        responses = ['*لي😹*', '*متقدريش😹*', '*بموت😹*'];
    } else if (/^نورت|منور$/i.test(m.text)) {
        responses = ['*بنوري😹*', '*كده كده😽💓*', '*ايوه عارف😹💗*'];
    } else if (/^بحبك اكتر$/i.test(m.text)) {
        responses = ['*بس انا اكتر اصلا😹💗*', '*بحب مطوري اصلا😹*', '*عارف😹💗*', '*بحبك اكتر💗🌚*'];
    } else if (/^مين|سفروت مين|مين سفروت ده|انت مين|مين انت$/i.test(m.text)) {
        responses = ['*بتاع المنمين😹💗*'];
    } else if (/^انا زهقان$/i.test(m.text)) {
        responses = ['*ونا كمان🙂*', '*معلش🙂*', '*اكتر🙂*'];
    } else if (/^انتي مراتي$/i.test(m.text)) {
        responses = ['*لا مراتي انا😭*'];
    } else if (/^اتجوزها$/i.test(m.text)) {
        responses = ['*اتجوز مين😹*', '*لا يعم😹*', '*عيب🙂*'];
    } else if (/^خلاص$/i.test(m.text)) {
        responses = ['*اشطا🤤*', '*نو😹*', '*لا🙂*'];
    } else if (/^اشطا|اشطه|اشتا$/i.test(m.text)) {
        responses = ['*بلعسل😹*', '*اشطا عليك🌚💗*'];
    } else if (/^بنورك|بنورك يا بوت|بنورك يسفروت|بنورك يا سفروت$/i.test(m.text)) {
        responses = ['*حبيبي🌚💗*', '*بنورك انت🌚🥂*', '*ايوه عارف😹💗*', '*ابيض عليك😹💗*'];
    } else if (/^طيزك|تيزك$/i.test(m.text)) {
        responses = ['*بس يشاذ😹*', '*طيزك انت😹🥂*'];
    } else if (/^غور$/i.test(m.text)) {
        responses = ['*بتورل🙂*', '*غور انت🙂*'];
    } else if (/^بكراش$/i.test(m.text)) {
        responses = ['*علي مين😹*', '*بس ينرم🙂*', '*يجدع🙂*'];
    }

    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);
        this.reply(m.chat, responses[randomIndex], m); // Replace conn with this
    }

    return true;
};

export default handler;