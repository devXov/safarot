//بحقوق سفروت الكبير
import { canLevelUp } from '../lib/levelling.js'
import canvafy from 'canvafy'

export async function before(m) {
	let user = global.db.data.users[m.sender]
    if (!user.autolevelup)
        return !0
    let before = user.level * 1
    while (canLevelUp(user.level, user.exp, global.multiplier))
        user.level++

	if (user.level <= 2) {
		user.role = 'جديد ㋡'
	} else if (user.level <= 4) {
		user.role = 'درجة مبتدئ 1 ⚊¹'
	} else if (user.level <= 6) {
		user.role = 'درجة مبتدئ 2 ⚊²'
	} else if (user.level <= 8) {
		user.role = 'درجة مبتدئ 3 ⚊³'
	} else if (user.level <= 10) {
		user.role = 'درجة مبتدئ 4 ⚊⁴'
	} else if (user.level <= 12) {
		user.role = 'درجة جندي 1 ⚌¹'
	} else if (user.level <= 14) {
		user.role = 'درجة جندي 2 ⚌²'
	} else if (user.level <= 16) {
		user.role = 'درجة جندي 3 ⚌³'
	} else if (user.level <= 18) {
		user.role = 'درجة جندي 4 ⚌⁴'
	} else if (user.level <= 20) {
		user.role = 'درجة جندي 5 ⚌⁵'
	} else if (user.level <= 22) {
		user.role = 'درجة عريف 1 ☰¹'
	} else if (user.level <= 24) {
		user.role = 'درجة عريف 2 ☰²'
	} else if (user.level <= 26) {
		user.role = 'درجة عريف 3 ☰³'
	} else if (user.level <= 28) {
		user.role = 'درجة عريف 4 ☰⁴'
	} else if (user.level <= 30) {
		user.role = 'درجة عريف 5 ☰⁵'
	} else if (user.level <= 32) {
		user.role = 'درجة رقيب 1 ≣¹'
	} else if (user.level <= 34) {
		user.role = 'درجة رقيب 2 ≣²'
	} else if (user.level <= 36) {
		user.role = 'درجة رقيب 3 ≣³'
	} else if (user.level <= 38) {
		user.role = 'درجة رقيبe 4 ≣⁴'
	} else if (user.level <= 40) {
		user.role = 'درجة رقيب 5 ≣⁵'
	} else if (user.level <= 42) {
		user.role = 'درجة موظف 1 ﹀¹'
	} else if (user.level <= 44) {
		user.role = 'درجة موظف 2 ﹀²'
	} else if (user.level <= 46) {
		user.role = 'درجة موظف 3 ﹀³'
	} else if (user.level <= 48) {
		user.role = 'درجة موظف 4 ﹀⁴'
	} else if (user.level <= 50) {
		user.role = 'درجة موظف 5 ﹀⁵'
	} else if (user.level <= 52) {
		user.role = 'درجة رقيب 1 ︾¹'
	} else if (user.level <= 54) {
		user.role = 'درجة رقيب 2 ︾²'
	} else if (user.level <= 56) {
		user.role = 'درجة رقيب 3 ︾³'
	} else if (user.level <= 58) {
		user.role = 'درجة رقيب 4 ︾⁴'
	} else if (user.level <= 60) {
		user.role = 'درجة رقيب 5 ︾⁵'
	} else if (user.level <= 62) {
		user.role = 'الملازم الثاني 1 ♢¹ '
	} else if (user.level <= 64) {
		user.role = 'الملازم الثاني 2 ♢²'
	} else if (user.level <= 66) {
		user.role = 'الملازم الثاني 3 ♢³'
	} else if (user.level <= 68) {
		user.role = 'الملازم الثاني 4 ♢⁴'
	} else if (user.level <= 70) {
		user.role = 'الملازم الثاني 5 ♢⁵'
	} else if (user.level <= 72) {
		user.role = 'الملازم الأول 1 ♢♢¹'
	} else if (user.level <= 74) {
		user.role = 'الملازم الأول 2 ♢♢²'
	} else if (user.level <= 76) {
		user.role = 'الملازم الأول 3 ♢♢³'
	} else if (user.level <= 78) {
		user.role = 'الملازم الأول 4 ♢♢⁴'
	} else if (user.level <= 80) {
		user.role = 'الملازم الأول 5 ♢♢⁵'
	} else if (user.level <= 82) {
		user.role = 'درجة 1 ✷¹'
	} else if (user.level <= 84) {
		user.role = 'درجة 2 ✷²'
	} else if (user.level <= 86) {
		user.role = 'درجة 3 ✷³'
	} else if (user.level <= 88) {
		user.role = 'درجة 4 ✷⁴'
	} else if (user.level <= 90) {
		user.role = 'درجة 5 ✷⁵'
	} else if (user.level <= 92) {
		user.role = 'درجة العقيد 1 ✷✷¹'
	} else if (user.level <= 94) {
		user.role = 'درجة العقيد 2 ✷✷²'
	} else if (user.level <= 96) {
		user.role = 'درجة العقيد 3 ✷✷³'
	} else if (user.level <= 98) {
		user.role = 'درجة العقيد 4 ✷✷⁴'
	} else if (user.level <= 100) {
		user.role = 'درجة العقيد 5 ✷✷⁵'
	} else if (user.level <= 102) {
		user.role = 'مبكر ✰'
	} else if (user.level <= 104) {
		user.role = 'فضي ✩'
	} else if (user.level <= 106) {
		user.role = 'جولد ✯'
	} else if (user.level <= 108) {
		user.role = 'بلاتيني ✬'
	} else if (user.level <= 110) {
		user.role = 'الماس ✪'
	} else if (user.level <= 112) {
		user.role = 'مبكر ✰'
	} else if (user.level <= 114) {
		user.role = 'فضي ✩'
	} else if (user.level <= 116) {
		user.role = 'جولد ✯'
	} else if (user.level <= 118) {
		user.role = 'بلاتيني ✬'
	} else if (user.level <= 120) {
		user.role = 'الماسي ✪'
	} else if (user.level <= 122) {
		user.role = 'مبكر ✰'
	} else if (user.level <= 124) {
		user.role = 'فضي ✩'
	} else if (user.level <= 126) {
		user.role = 'جولد ✯'
	} else if (user.level <= 128) {
		user.role = 'البلاتيني ✬'
	} else if (user.level <= 130) {
		user.role = ' الماسي ✪'
	} else if (user.level <= 132) {
		user.role = ' المبكر ✰'
	} else if (user.level <= 134) {
		user.role = ' الفضي ✩'
	} else if (user.level <= 136) {
		user.role = ' الذهبي ✯'
	} else if (user.level <= 138) {
		user.role = ' البلاتيني ✬'
	} else if (user.level <= 140) {
		user.role = ' الماسي ✪'
	} else if (user.level <= 142) {
		user.role = 'القائد المبكر ★'
	} else if (user.level <= 144) {
		user.role = 'القائد المتوسط ⍣'
	} else if (user.level <= 146) {
		user.role = 'القائد النخبة ≛'
	} else if (user.level <= 148) {
		user.role = 'القائد البطل ⍟'
	} else if (user.level <= 152) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 154) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 156) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 158) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 160) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 162) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 164) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 166) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 168) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 170) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 172) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 174) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 176) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 178) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 180) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 182) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 184) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 186) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 188) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 190) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 192) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 194) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 196) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 198) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 200) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 210) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 220) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 230) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 240) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 250) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 260) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 270) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 280) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 290) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 300) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 310) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 320) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 330) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 340) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 350) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 360) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 370) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 380) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 390) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 400) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 410) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 420) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 430) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 440) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 450) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 460) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 470) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 480) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 490) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 500) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 600) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 700) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 800) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 900) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 1000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 2000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 3000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 4000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 5000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 6000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 7000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 8000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 9000) {
		user.role = 'أساطير 忍'
	} else if (user.level <= 10000) {
		user.role = 'اساطير🧚🏻‍♀️'
	}
	//user.role = role

	if (before !== user.level) {
		let ini_txt = `> *وصلت لي مستوى جديد🧚🏻‍♀️*\n\n> تابع مستواك *${before}*> *${user.level}*\n> *الترقيه* : *${user.role}*`.trim()
		let nama = await conn.getName(m.sender)
		let status = user.premium ? 'Premium' : 'Free'
		try {
			let image, data, pp
			try {
				pp = await this.profilePictureUrl(m.sender, 'image')
			} catch {
				pp = 'https://i.ibb.co/m53WF9N/avatar-contact.png'
			}
        image = await new canvafy.LevelUp()
    .setAvatar(pp)
    .setBackground("image", "https://files.catbox.moe/kf8f9l.jpg")
    .setUsername(nama)
    .setBorder("#000000")
    .setAvatarBorder("#ff0000")
    .setOverlayOpacity(0.7)
    .setLevels(before,user.level)
    .build();
			await this.sendMessage(m.chat, { image: image, caption: ini_txt }, { quoted: m })
		} catch {
			await m.reply(ini_txt)
		}
	}
}
export const disabled = false