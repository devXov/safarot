import fs from 'fs';

const handler = async (m, { conn, args }) => {
  const group = m.chat;

  // الحصول على بيانات الجروب
  const groupMetadata = await conn.groupMetadata(group);
  const groupName = groupMetadata.subject; // اسم الجروب
  const groupDesc = groupMetadata.desc || 'لا يوجد وصف متاح'; // وصف الجروب

  // رابط الصورة الافتراضية
  const defaultImageUrl = 'https://files.catbox.moe/lj1ba5.jpg';

  let groupPicture;
  try {
    // محاولة الحصول على صورة الجروب
    groupPicture = await conn.profilePictureUrl(group, 'image');
  } catch (e) {
    // في حالة حدوث خطأ (مثل عدم وجود صورة)، استخدم الصورة الافتراضية
    groupPicture = defaultImageUrl;
  }

  // رابط الدعوة
  const link = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(group);

  // نص الرسالة مع تفاصيل الجروب بدون زر النسخ
  const cap = `━━━━━━━━❰･𓃦･❱━━━━━━━━\n\n> ≡ ◡̈⃝❯ *\`『 اسم الجروب 🧚🏻‍♂️ 』\`*: ${groupName}\n> ≡ ◡̈⃝❯ *\`『 الوصف 』\`* ${groupDesc}\n\n♡         ㅤ    ❍ㅤ       ⎙ㅤ           ⌲\n━━━━━━━━❰･𓃠･❱━━━━━━━━`;
  const wm = '𝐒𝐀𝐅𝐑𝐎𝐓-𝐁𝐎𝐓'; 
  
  // إرسال الرسالة مع صورة الجروب والتفاصيل بدون أي زر
  await conn.sendMessage(m.chat, { image: { url: groupPicture }, caption: `${cap}\n\n${wm}\n\nرابط الجروب: ${link}` }, { quoted: m });
};

handler.help = ['linkgroup'];
handler.tags = ['group'];
handler.command = /^link|لينك(gro?up)?$/i;
handler.group = true;
handler.botAdmin = true;

export default handler;