// بحقوق المطور ♯ЅᗩFᏒOT꙯ https://whatsapp.com/channel/0029VaxDFMOEVccHJn4fXD42
// https://wa.me/+201115618853?s.whatsapp.net/?text=💗

import axios from "axios";

let handler = async (m, { conn }) => {
    try {
        await m.reply('> *\`『 لحظة من فضلك 🧚🏻‍♂️ 』\`*');
        const رابط = "https://fgsi-kalender.hf.space/";
        const استجابة = await axios.get(رابط, {
            responseType: "arraybuffer"
        });

        const التاريخ = new Date();
        const خيارات = {
            weekday: "long",  
            day: "numeric",  
            month: "long",   
            year: "numeric",  
            timeZone: "Africa/Cairo",
        };

        const نص_التاريخ = new Intl.DateTimeFormat("ar-EG", خيارات).format(التاريخ); 
        const الصورة = استجابة.data;

        const النص = `📆 *التقويم اليومي:*\n\n📅 *اليوم:* ${new Intl.DateTimeFormat("ar-EG", { weekday: "long", timeZone: "Africa/Cairo" }).format(التاريخ)}\n📆 *التاريخ:* ${new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "long", year: "numeric", timeZone: "Africa/Cairo" }).format(التاريخ)}\n🕰️ *المنطقة الزمنية:* مصر`;

        await conn.sendFile(
            m.chat,
            الصورة,
            "التقويم.jpg",
            النص,
            m
        );
    } catch (e) {
        console.error(e);
        m.reply("حدث خطأ أثناء جلب الصورة من الموقع!");
    }
};

handler.help = ['التقويم'];
handler.tags = ['♯ЅᗩFᏒOT꙯'];
handler.command = /^التقويم$/i;

export default handler;