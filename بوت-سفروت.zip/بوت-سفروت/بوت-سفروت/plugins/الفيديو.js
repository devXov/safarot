// تحميل الفيديوهات من يوتيوب بصيغة MP4

import fetch from 'node-fetch';
import ytSearch from 'yt-search';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`*[❗] مثال الاستخدام*: ${usedPrefix + command} <رابط فيديو يوتيوب>`);
  }

  try {
    // إرسال رد فعل الانتظار
    await m.react('⏳');

    // جلب تفاصيل الفيديو باستخدام yt-search
    const videoInfo = await ytSearch({ videoId: text.split('v=')[1] });

    if (!videoInfo) {
      throw new Error('لم يتم العثور على الفيديو باستخدام yt-search.');
    }

    const apiUrl = `https://api.davidcyriltech.my.id/download/ytmp4?url=${encodeURIComponent(text)}`;
    const response = await fetch(apiUrl);

    if (!response.ok) {
      throw new Error(`فشل في الاتصال بالـ API. رمز الحالة: ${response.status}`);
    }

    const result = await response.json();

    // تسجيل نتيجة الـ API للتأكد من البنية
    console.log('استجابة API:', result);

    if (result.status && result.result) {
      // إرسال رد فعل النجاح
      await m.react('✅');

      const fileUrl = result.result.download_url;
      const mimeType = 'video/mp4';
      const fileName = `${result.result.title}.mp4`;

      // معلومات الفيديو
      const videoDetails = `
*🎥 معلومات الفيديو:*
- *العنوان:* ${videoInfo.title}
- *القناة:* ${videoInfo.author.name}
- *عدد المشاهدات:* ${videoInfo.views.toLocaleString()}
- *تاريخ النشر:* ${videoInfo.ago}
- *المدة:* ${videoInfo.timestamp}
- *الرابط:* ${videoInfo.url}
      `.trim();

      // إرسال الفيديو مع التفاصيل في الوصف
      await conn.sendMessage(m.chat, {
        video: { url: fileUrl }, // استخدام رابط الفيديو
        mimetype: mimeType, // تحديد نوع الملف
        fileName: fileName, // اسم الملف
        caption: videoDetails, // إضافة وصف الفيديو
      }, { quoted: m }); // اقتباس الرسالة الأصلية
    } else {
      console.error('استجابة غير صالحة من API:', result);
      throw new Error("استجابة غير صالحة من API. يرجى التحقق من البنية.");
    }
  } catch (error) {
    // إرسال رد فعل خطأ
    await m.react('❌');
    console.error('حدث خطأ:', error); // تسجيل الخطأ لتصحيح الأخطاء
    m.reply("حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.");
  }
};

handler.help = ['تحميل_فيديو'];
handler.command = /^(تحميل_فيديو|تنزيل_فيديو|الفيديو)$/i;
handler.tags = ['downloader'];

export default handler;