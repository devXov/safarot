let handler = async (m, { conn, usedPrefix, text }) => {
    let number;

    // التحقق من النص إذا كان رقمًا أو يحتوي على @
    if (isNaN(text) && !text.match(/@/g)) {
        // النص ليس رقمًا ولا يحتوي على @
    } else if (isNaN(text)) {
        number = text.split`@`[1]; // استخراج الرقم بعد @
    } else if (!isNaN(text)) {
        number = text; // النص رقم
    }

    // التحقق من وجود النص أو الرسالة المقتبسة
    if (!text && !m.quoted) {
        return conn.reply(
            m.chat,
            `*[❗] اترقيت لمشرف*\n\n*┯┷*\n*┠≽ ${usedPrefix}daradmin @tag*\n*┠≽ ${usedPrefix}darpoder -> responder a un mensaje*\n*┷┯*`,
            m
        );
    }

    // التحقق من صحة الرقم (إذا كان موجودًا)
    if (number && (number.length > 13 || (number.length < 11 && number.length > 0))) {
        return conn.reply(
            m.chat,
            `*[ ⚠️ ] El número ingresado es incorrecto, por favor ingrese el número correcto*`,
            m
        );
    }

    try {
        let user;
        if (text) {
            user = number + '@s.whatsapp.net';
        } else if (m.quoted?.sender) {
            user = m.quoted.sender;
        } else if (m.mentionedJid) {
            user = number + '@s.whatsapp.net';
        }

        // تحديث المستخدم كمشرف
        if (user) {
            await conn.groupParticipantsUpdate(m.chat, [user], 'promote');
            conn.reply(m.chat, `*\`『 تم يحب🧚🏼‍♂️ 』\`*`, m);
        } else {
            conn.reply(m.chat, `*[ ⚠️ ] لم يتم العثور على المستخدم*`, m);
        }
    } catch (e) {
        console.error(e);
        conn.reply(m.chat, `*[ ⚠️ ] حدث خطأ أثناء محاولة الترقية*`, m);
    }
};

// دعم الأمر مع أي نص بجانبه
handler.help = ['رفع', 'ترقيه'];
handler.tags = ['owner'];
handler.command = /^(ترقيه|رفع)(\s.*)?$/i; // تعديل التعبير المنتظم لقبول أي نص بعد الأمر
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.fail = null;

export default handler;