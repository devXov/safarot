 import { readdirSync, unlinkSync, existsSync } from 'fs'

let handler = async (m, { conn, args }) => {
  m.reply('*\`『 تم تنظيف ملفات البوت يا مطوري 🧚🏻‍♂️ 』\`*')
  m.react(done)
  
  // session bot
  readdirSync("./BotSession").forEach(file => {
    const filePath = "./BotSession/" + file
    if (file !== 'creds.json' && existsSync(filePath)) {
      unlinkSync(filePath)
    }
  })
}

handler.help = ['cleartmp']
handler.tags = ['owner']
handler.command = /^(تنظيف)$/i
handler.owner = true

export default handler