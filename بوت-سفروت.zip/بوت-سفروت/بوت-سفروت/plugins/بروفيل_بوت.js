            const finalBuffer = await resizedImage.getBufferAsync(jimp.MIME_JPEG);
            return { img: finalBuffer }
        }

        const { img: processedImage } = await processImage(imageBuffer);

        await conn.query({ tag: 'iq', attrs: { to: contactId, type: 'set', xmlns: 'w:profile:picture' }, content: [{ tag: 'picture', attrs: { type: 'image' }, content: processedImage }]});

        await message.reply(' *🧚🏽‍♂️ تم تغيير صورة البروفايل بتاعة البوت بنجاح* ');
    } catch {
        throw ` *هات الصوره🧚🏽‍♂️ ${usedPrefix + command}*`;
    }
};

handler.help = ["setppbot"]
handler.tags = ["owner"]
handler.command = /^برفبوت|بروفيلك|fotobot$/i;
handler.owner = true;

export default handler;