import fetch from 'node-fetch';

/*
هديه الي متابعيني الاعزاء 🫣💗.
حقوق القنوات :
https://whatsapp.com/channel/0029VasoQ3rEFeXn7Ij6oG37


https://whatsapp.com/channel/0029Vael6wMJP20ze3IXJk0z
ملكية : ⛊  Ealam, 𝚂𝙰𝚈𝙴𝙳-𝚂𝙷𝙰𝚆𝙰𝚉𝙰
*/


const handler = async (m, { command, usedPrefix, conn, args, text }) => {

await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

let txt = text;

if (!text && m.quoted && m.quoted.text) {
txt = m.quoted.text;
}

if (!txt) {
     await conn.sendMessage(m.chat, {
      text: `❗ الرجاء إدخال نص أو الرد على رسالة تحتوي على نص.`,
    }, {quoted: m}); 
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    return;
  }

try{

let img = `https://the-end-api.vercel.app/api/ai/text-image?q=${encodeURIComponent(txt)}`;

await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

await conn.sendMessage(m.chat, {image: {url: img}}, {quoted: m});
 

 await conn.sendMessage(m.chat, { react: { text: '👌🏻', key: m.key } });
 
 } catch {
 await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 }
 };
 
 handler.command = /^(تخيل)$/i;
export default handler;