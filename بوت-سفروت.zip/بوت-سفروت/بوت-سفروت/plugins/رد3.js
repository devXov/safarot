let handler = m => m;

handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat];
    let responses;

    if (/^حصل|حثل$/i.test(m.text)) {
        responses = [
            '*وبيحصل🙂*'
        ];
    } else if (/بقولك|باولك^$/i.test(m.text)) {
        responses = [
           '*قولي🙂*',
             '*ارغي🐤*'
        ];
    } else if (/^رول$/i.test(m.text)) {
        responses = [
            '*انت هتصحبني🐤😹*',
            '*قول للادمن🐤*',
            '*لا🐤*'
        ];
    } else if (/^تتقوزني|تتجوزني$/i.test(m.text)) {
        responses = [
            '*لما تكبري😹*',
            '*موافق😹💋*'
        ];
    } else if (/^هات بوسه|جيب بوسه|قيب بوسه$/i.test(m.text)) {
        responses = [
          '*يلي موشمحترم🙂*',
            '*بتقرف🙂*',
             '*امووووووه💋💗*'
        ];
    } else if (/^ربنا يسمحك$/i.test(m.text)) {
        responses = [
            '*انت خت حسنات وهوا خد فيها😹🐤*'
        ];
    } else if (/^زحلان|زعلان|زعلتني$/i.test(m.text)) {
        responses = [
          '*حقك عليا🙂*', 
             '*😹اتفلق*'
        ];
    } else if (/^هموت|بموووت|هموووت|بموتتت|بفطس|بفتس$/i.test(m.text)) {
        responses = [
        '*ونا مالي🙂*',  
            '*الحقو😹*',
             '*انت شرقت🙂*'
        ];
    } else if (/^احترمني$/i.test(m.text)) {
        responses = [
            '*مين انت معلش😹*'
        ];
    } else if (/^انت بتكرف|بتكرف$/i.test(m.text)) {
        responses = [
          '*مش شيفك😹*',
            '*ايوه😹*',
             '*يمكن مشغول🙂*'
        ];
    } else if (/^بوت وحش|بوت وحث$/i.test(m.text)) {
        responses = [
            '*محثلش😹*',
            '*كداب😹*',
            '*كداب موت😹*'
        ];
    } else if (/^البوت الخول|خول البوت$/i.test(m.text)) {
        responses = [
            '*حد قلك اني شبهك😹*'
        ];
    } else if (/^كداب|بيكدب$/i.test(m.text)) {
        responses = [
            '*محثلش😹*',
            '*لا طبعا😹*',
            '*يظلمين🙂*'
        ];
    } else if (/^وحشني|وحشتني$/i.test(m.text)) {
        responses = [
            '*وحشتني اكتر🙂💗*',
            '*وانت كمان😹💗*',
            '*وحشني اكتر🌚💕*'
        ];
    } else if (/^يتي|يوغتي|يتيي$/i.test(m.text)) {
        responses = [
            '*يوغتيي😹*',
            '*يتي*'
        ];
    } else if (/^الغي البوت|شيل البوت|خرج البوت|طلع البوت|اطرد البوت|طير البوت|شيل البوت|حوش البوت$/i.test(m.text)) {
        responses = [
            '🙂💔'
        ];
    } else if (/^انت زعلان$/i.test(m.text)) {
        responses = [
            '*ايوه🙂*'
        ];
    } else if (/^بقولك بضان$/i.test(m.text)) {
        responses = [
            '*كداب🙂*'
        ];
    } else if (/^الود سفروت$/i.test(m.text)) {
        responses = [
            '*سفروت عمك💗🥂*',
            '*عمك سفروت💗🥂*'
        ];
    } else if (/^بوت شاز|بوت شاذ$/i.test(m.text)) {
        responses = [
            '*شيفني شبهك😁❗*'
        ];
    } else if (/^كوسم البوت|كوسمك بوت|كوسم سفروت|كوسمك يا سفروت$/i.test(m.text)) {
        responses = [
         '*احدف كسمك😁❗*',
             '*كسمك بمعني الصح كسمك انت😁❗*',
             '*علي كسم امك😁❗*',
            '*كسمك بيحبني😁❗*'
        ];
    } else if (/^يبصاني|يابضاني$/i.test(m.text)) {
        responses = [
            '*🙂يبضاني انا*'
        ];
    } 
    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);
        conn.reply(m.chat, responses[randomIndex], m);
    }
    return !0;
};

export default handler;