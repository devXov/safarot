import fetch from 'node-fetch';

let handler = async (m, { command, usedPrefix, conn, args, text }) => {
  if (!text) {
    await conn.sendMessage(
      m.chat,
      {
        text: `*❲ ❗ ❳ يرجى إدخال رابط لتحميل الملف.*\nمثال:\n> ➤ ${usedPrefix + command} https://www.instagram.com/p/C8SOt4mINVm/`,
      },
      { quoted: m }
    );
    return;
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  const link = text.trim();
  let data = await downloadInstagramMedia(link);

  if (data.error) {
    await conn.sendMessage(
      m.chat,
      { text: `❗ لم يتم العثور على الملف أو حدث خطأ أثناء التحميل: ${data.error}` },
      { quoted: m }
    );
    return;
  }

  const { mediaUrl } = data;

  if (!mediaUrl || mediaUrl === 'غير متوفر') {
    await conn.sendMessage(m.chat, { text: "❗ لم يتم العثور على الوسائط المناسبة." }, { quoted: m });
    return;
  }

  await conn.sendMessage(m.chat, { video: { url: mediaUrl }, mimetype: "video/mp4", fileName: 'ig.mp4' }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: "🚀", key: m.key } });
};

handler.command = /^(انستا|ig)$/i;
export default handler;

async function downloadInstagramMedia(link) {
  try {
    const url = `https://bk9.fun/download/instagram2?url=${link}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`فشل الاتصال بالخادم: ${response.statusText}`);
    }

    const result = await response.json();

    if (result && result.BK9 && result.BK9.length > 0) {
      const media = result.BK9[0].url;

      return {
        mediaUrl: media || "غير متوفر",
        error: null,
      };
    } else {
      throw new Error("لم يتم العثور على البيانات المناسبة.");
    }
  } catch (error) {
    console.error("خطأ أثناء تحميل الوسائط:", error.message);
    return { error: error.message };
  }
}