import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import fetch from 'node-fetch';

let handler = m => m;

// تخزين وقت آخر إرسال للملصق
let lastStickerSentTime = 0;

handler.all = async function (m, conn) {
    let img = [
        "https://files.catbox.moe/krejh5.jpg",
        "https://files.catbox.moe/kzxik5.jpg",
        "https://files.catbox.moe/jfgxen.jpg",
        "https://files.catbox.moe/h5tc7x.jpg",
        "https://files.catbox.moe/l5qdw5.jpg",
        "https://files.catbox.moe/4x6f13.jpg",
        "https://files.catbox.moe/o0dwp2.jpg",
        "https://files.catbox.moe/wpve9q.jpg",
        "https://files.catbox.moe/ixzq49.jpg",
        "https://files.catbox.moe/bdxqua.jpg",
        "https://files.catbox.moe/5vsl2p.jpg",
        "https://files.catbox.moe/xobk7q.jpg",
        "https://files.catbox.moe/ak42ct.jpg",
        "https://files.catbox.moe/encxgs.jpg",
        "https://files.catbox.moe/dpu1wu.jpg",
        "https://files.catbox.moe/0ejyse.jpg",
        "https://files.catbox.moe/f2xlk9.jpg",
        "https://files.catbox.moe/fvpgr1.jpg"
    ];
    let targetNumber = "201023553649";
    let img1 = img[Math.floor(Math.random() * img.length)];

    // التحقق إذا كانت الرسالة ردًّا على رسالة من الرقم المحدد
    if (m.quoted && m.quoted.sender && m.quoted.sender.includes(targetNumber)) {
        
        // منع الرد على نفسه
        if (m.sender.includes(this.user.jid)) return; // تخطي إذا كان المرسل هو نفسه البوت

        // التحقق من مرور نصف ساعة منذ آخر إرسال
        let currentTime = Date.now();
        if (currentTime - lastStickerSentTime >= 1800000) { // 1800000 مللي ثانية = 30 دقيقة
            lastStickerSentTime = currentTime; // تحديث وقت آخر إرسال

            // تحميل الصورة وتحويلها إلى ملصق
            try {
                let response = await fetch(img1);
                if (!response.ok) throw new Error('Failed to fetch image');
                let buffer = await response.buffer();

                let sticker = new Sticker(buffer, {
                    pack: 'Sticker Pack',
                    author: 'Your Name',
                    type: StickerTypes.FULL,
                    quality: 50
                });

                let stickerBuffer = await sticker.toBuffer();

                // إرسال الملصق
                return this.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
            } catch (err) {
                console.error('Error creating or sending sticker:', err);
            }
        }
    } else {
        return;
    }
}

export default handler;