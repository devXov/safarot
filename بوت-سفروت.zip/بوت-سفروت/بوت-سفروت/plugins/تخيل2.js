import fetch from 'node-fetch'; 

let handler = async (m, { conn, text, usedPrefix, command }) => {

    // لو المستخدم ما كتبش حاجة بعد الأمر

    if (!text) {

        if (command === 'تخيل-كرتون') {

            await m.reply('> *\`『 اكتب الكرتون الي بتتخيلو معا الامر 🧚🏻‍♂️ 』\`*');

        } else if (command === 'تخيل-انمي') {

            await m.reply('> *\`『 اكتب الانمي الي بتتخيلو معا الامر 🧚🏻‍♂️ 』\`*');

        } else if (command === 'تخيل-رسم') {

            await m.reply('> *\`『 اكتب الرسم الي بتتخيلو معا الامر 🧚🏻‍♂️ 』\`*');

        } else if (command === 'تخيل-حقيقي') {

            await m.reply('> *\`『 اكتب الي بتتخيلو حقيقي معا الامر 🧚🏻‍♂️ 』\`*');

        }

        return; // نوقف العملية لحد ما المستخدم يكتب النص المطلوب

    }

    const msg = encodeURIComponent(text);

    try {

        // إضافة ريك التحميل

        await m.react('🧚🏻‍♂️'); // ريك التحميل

        const response = await fetch(`https://api.joanimi-world.site/api/tr?text=${msg}&lang=en`);

        const result = await response.json();

        const translatedText = result.result;

        let model;

        if (command === 'تخيل-كرتون') {

            model = `cartoon`;

        } else if (command === 'تخيل-انمي') {

            model = `anime`;

        } else if (command === 'تخيل-رسم') {

            model = `paint`;

        } else if (command === 'تخيل-حقيقي') {

            model = `real/v1`;

        }

        const generator = `https://api.joanimi-world.site/api/text2${model}?text=${translatedText}`;

        await conn.sendFile(m.chat, generator, 'generator.png', '', m, false);

        

        await m.react('✅'); 

    } catch (error) {

        

        await m.react('❌'); 

    }

};

handler.tags = ['اتخيل'];

handler.tags = ['ai'];

handler.command = /^(تخيل-كرتون|تخيل-انمي|تخيل-رسم|تخيل-حقيقي)$/i;

export default handler;