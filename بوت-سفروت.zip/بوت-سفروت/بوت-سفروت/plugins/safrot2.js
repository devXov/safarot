  export async function before(m, { conn, isAdmin, isBotAdmin }) {
  const delet = m.key.participant;
  const bang = m.key.id;
  const botNumber = this.user.jid; 
  const owner = "01115618853@s.whatsapp.net"; // استبدل هذا بالقيمة الصحيحة للمالك

  if (m.isBaileys && m.fromMe) {
    return true; 
  }

  if (!m.isGroup) return false;

  const forbiddenWords = ["https://chat.whatsapp"]; 
  const messageText = m.text.toLowerCase().trim(); 

  for (let word of forbiddenWords) {
    const regex = new RegExp(`${word}`, 'i');

    if (regex.test(messageText)) {
      // تحقق مما إذا كان المرسل ليس البوت أو المطور
      if (m.key.participant !== botNumber && m.key.participant !== owner && !isAdmin) {
        // إذا لم يكن المرسل هو البوت أو المطور، يتم حذف الرسالة
        await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet } });
      }
      break; 
    }
  }

  return true;
}