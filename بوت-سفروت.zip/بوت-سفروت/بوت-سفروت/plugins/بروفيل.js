import PhoneNumber from 'awesome-phonenumber'
import fetch from 'node-fetch'

var handler = async (m, { conn }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => imagen1)
    let { premium, level, cookies, exp, lastclaim, registered, regTime, age, role } = global.db.data.users[m.sender]
    let username = conn.getName(who)

    let noprem = `
🚩 *ملف المستخدم*
☁️ *الاسم:* ${username}
💥 *التاج:* @${who.replace(/@.+/, '')}
🌀 *مسجل:* ${registered ? '✅': '❌'}

👑 *الموارد*
🍪 *الكوكيز:* ${cookies}
💥 *المستوى:* ${level}
💫 *الخبرة:* ${exp}
✨️ *الدور:* ${role}

💖 *بريميوم:* ${premium ? '✅': '❌'}
`.trim()

    let prem = `╭──⪩ 𝐔𝐒𝐔𝐀𝐑𝐈𝐎 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 ⪨
│⧼👤⧽ *المستخدم:* 「${username}」
│⧼💌⧽ *مسجل:* ${registered ? '✅': '❌'}
│⧼🔱⧽ *الدور:* مميز 👑
╰───⪨

╭────⪩ 𝐑𝐄𝐂𝐔𝐑𝐒𝐎𝐒 ⪨
│⧼🍪⧽ *الكوكيز:* ${cookies}
│⧼🔰⧽ *المستوى:* ${level}
│⧼💫⧽ *الخبرة:* ${exp}
│⧼⚜️⧽ *الدور:* ${role}
╰───⪨ *𝓤𝓼𝓾𝓪𝓻𝓲𝓸 𝓓𝓮𝓼𝓽𝓪𝓬𝓪𝓭𝓸* ⪩`.trim()

    conn.sendFile(m.chat, pp, 'perfil.jpg', `${premium ? prem.trim() : noprem.trim()}`, m, { mentions: [who] })
}

handler.help = ['profile']
handler.tags = ['rg']
handler.command = ['بروفيلي', 'بروفيل']

export default handler