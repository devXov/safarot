import fs from 'fs';

const handler = (m) => m;

handler.all = async function (m) {
  const chat = global.db.data.chats[m.chat];

  // Check if the sender's number matches the blocked ones
  const blockedNumbers = ['201115618853', '201023553649'];
  if (blockedNumbers.includes(m.sender)) return;

  // Ignore messages sent by the bot itself
  if (m.sender === m.conn.user.jid) return;

  const randomReply = (replies) => replies[Math.floor(Math.random() * replies.length)];

  // Check if the message is a reply to the bot's message
  if (!m.quoted || m.quoted.sender !== m.conn.user.jid) return;

  if (/^كسمك|قسمك|كوسمك|كسمين امك$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*ابويا نط ع امك😹🔥*',
      '*واحد ليك وعشره لمك😁🖕🏻*',
      '*احدف.امك😹🖕🏻*',
      '*ابويا فرقع بز امك😹🖕🏻*',
      '*كسمين امك😹🔥*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^هنيك|هنيكك|هنيقق|تع انيقق|انيققق|هنيقك$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*انت خول ياه😹🖕🏻*',
      '*انت متناك اصلا😹🖕🏻*',
      '*يبني انت بتتناك😹🖕🏻*',
      '*يبني انت بتتناك وهطل😹🔥*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^ابن متناكه|متناكه|يبن المتناكه|انت ابن متناكه$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*مافيش متناكه من بعد امك😹🖕🏻*',
      '*المتناكه دي انتي يلبوه😹*',
      '*انت بتتناك ياض وهطل😹🔥*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^بوت خول|خول|خولل|سفروت خول$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*الخول ده ابوك الي جابك😹🔥*',
      '*حد قلق اني شبه ابوك الخول😹🔥*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^يابن البوه|يبن البوه$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*البوه دي امك الي جبتك🥵🖕🏻*',
      '*كسمك محشي عجوه🥵😹*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^يبن الاحبه|الاحبه|القحبه|يبن القحبه$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*كسمك😹🖕🏻*',
      '*الاحبه دي امك عارف😁🖕🏻*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^انت علق$/i.test(m.text) && !chat.isBanned) {
    const replies = ['*وانت متناك😹🔥*'];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^كس اختك|كسختك$/i.test(m.text) && !chat.isBanned) {
    const replies = [
      '*احدف اختك الشرموطه🥵*',
      '*احدف اختك البوه🥵*',
    ];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^مومس|يمومس|يبن المومس$/i.test(m.text) && !chat.isBanned) {
    const replies = ['*المومس ده ابوك الخول😹🖕🏻*'];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^يبن الزانيه|يابن الزانيه|يبن الزواني|يابن الزواني$/i.test(m.text) && !chat.isBanned) {
    const replies = ['*الزانيه دي امك عرفين😁🤩*'];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^طظ فيك|طو فيك|طظفيك|تظ فيك$/i.test(m.text) && !chat.isBanned) {
    const replies = ['*فيك انت😁🚯*'];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  } else if (/^يابن الفجره|يبن الفجره|يبن الفاجر|يابن الفاجر$/i.test(m.text) && !chat.isBanned) {
    const replies = ['*يبن ستين فجره😹🖕🏻*'];
    m.conn.sendMessage(m.chat, { text: randomReply(replies) }, { quoted: m });

  }

  return true;
};

export default handler;