let handler = async (m, { isOwner, isAdmin, conn, participants, args }) => {
    // التحقق من صلاحيات الأدمن أو المالك
    if (!(isAdmin || isOwner)) {
        return m.reply('انت مش أدمن أو مالك عشان تنفذ الأمر ده.')
    }

    // التحقق من وجود المشاركين
    if (!participants || participants.length === 0) {
        return m.reply('مفيش أعضاء في المجموعة.')
    }

    // جمع النص المدخل في رسالة واحدة أو تحديد رسالة افتراضية إذا لم يتم إدخال أي نص
    let pesan = args.join(' ') || '> *\`『 ميتنج 😹🙂 』\`*'
    let oi = `𓃠 *الرسالة:* ${pesan} 𓃦`
    let teks = `━━━━━━❰･منشن جماعي 🤾‍♂️･❱━━━━━━\n\n≡ ◡̈⃝❯ @${m.sender.split('@')[0]}\n\n❏ ${oi}\n\n❏ *🧚🏽‍♂️*\n`

    // إضافة منشن لكل عضو في المجموعة
    for (let mem of participants) {
        teks += `➥ @${mem.id.split('@')[0]}\n`
    }

    const wm = '≡◡̈⃝❯ *\`『 𝐒𝐀𝐅𝐑𝐎𝐓-𝐁𝐎𝐓 』\`*'
    teks += `━━━━━━❰･𓃠･❱━━━━━━\n${wm}`

    // إرسال الرسالة إلى الدردشة
    await conn.sendMessage(m.chat, { text: teks, mentions: [m.sender, ...participants.map(a => a.id)] })
}

handler.help = ['منشن الكل <رسالة>', 'استدعاء <رسالة>']
handler.tags = ['group']
handler.command = /^(tagall|منشن|استدعاء|الكل)$/i
handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler