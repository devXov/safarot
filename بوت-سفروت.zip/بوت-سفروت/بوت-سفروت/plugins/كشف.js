const handler = async (m, { conn }) => {
  if (!m.quoted) {
    return m.reply('> *\`『 ريب ع الي عايز تظهرو يحب 🧚🏻‍♂️ 』\`');
  }

  const quoted = m.quoted;
  const isViewOnce = Object.keys(quoted?.message || {})
    .map((key) => quoted?.message[key]?.viewOnce)
    .includes(true);

  if (!isViewOnce) {
    return m.reply('> *\`『 ريب ع الي عايز تظهرو يحب 🧚🏻‍♂️ 』\`*');
  }

  const buffer = await m?.quoted?.download?.().catch(() => {});
  const media = m?.quoted?.mediaMessage[m?.quoted?.mediaType];
  const mtype = media?.mimetype;

  // التحقق من نوع الوسائط
  const isImage = /image/.test(mtype);
  const isVideo = /video/.test(mtype);
  const isAudio = /audio/.test(mtype);

  if (isImage) {
    conn.sendMessage(
      m.chat,
      {
        image: buffer,
        ...(media?.caption && { caption: media?.caption }),
      },
      { quoted: m }
    );
  } else if (isVideo) {
    conn.sendMessage(
      m.chat,
      {
        video: buffer,
        caption: media?.caption,
      },
      { quoted: m }
    );
  } else if (isAudio) {
    conn.sendMessage(
      m.chat,
      {
        audio: buffer,
        caption: media?.caption,
        mimetype: mtype, // تأكد من إرسال نوع MIME الصحيح
      },
      { quoted: m }
    );
  } else {
    return m.reply('> *\`『 رد علي تسجيل صوت او صوره يحب 🧚🏻‍♂️ 』\`*');
  }
};

handler.help = ["قراءة_عرض_مرة_واحدة"];
handler.tags = ["أدوات"];
handler.command = ["اظهر", "كشف"];

export default handler;