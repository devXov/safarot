import fs from 'fs';

const timeout = 30000; // 30 ثانية
const poin = 500;

const handler = async (m, { conn }) => {
  conn.tekateki = conn.tekateki || {};

  const id = m.chat;

  if (id in conn.tekateki) {
    conn.reply(m.chat, '> *\`『 لسه عندك سؤال مجاوبتش عليه 🧚🏻‍♂️ 』\`*', conn.tekateki[id][0]);
    return;
  }

  const tekateki = JSON.parse(fs.readFileSync(`./src/game/ايمو.json`));
  const json = tekateki[Math.floor(Math.random() * tekateki.length)];

  const caption = `━━━━━━❰･𓃦･❱━━━━━━

ⷮ *${json.question}*

> *\`『 الوقت 』\`* ${(timeout / 1000).toFixed(2)} ثواني

> *\`『 الجايزه 』\`* +${poin} Exp

━━━━━━❰･𓃦･❱━━━━━`.trim();

  const imageUrl = 'https://i.ibb.co/3SXv5jj/file.jpg';

  // إعداد اللعبة
  conn.tekateki[id] = [
    await conn.sendFile(m.chat, imageUrl, 'image.jpg', caption, m),
    json,
    poin,
    setTimeout(async () => {
      if (conn.tekateki[id]) {
        await conn.reply(m.chat, `> *الوقت خلص وماجاوبتش على السؤال! 🕒*`);
        delete conn.tekateki[id]; // حذف اللعبة
      }
    }, timeout)
  ];
};

// التحقق من الإجابة
handler.checkAnswer = (m, conn) => {
  const id = m.chat;
  if (!(id in conn.tekateki)) {
    conn.reply(m.chat, '> *\`『 اللعبة انتهت بالفعل 😕 』\`*');
    return false;
  }
  return true;
};

// إعداد الأوامر
handler.help = ['ايمو'];
handler.tags = ['game'];
handler.command = /^(ايمو|ايموجي)$/i;

export default handler;