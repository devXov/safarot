//بحقوق المطور ♯ЅᗩFᏒOT꙯ https://whatsapp.com/channel/0029VaxDFMOEVccHJn4fXD42
//https://wa.me/+201115618853@s.whatsapp.net/?text=💗


import cheerio from "cheerio";
import axios from "axios";

let handler = async (m, { conn, args }) => {
    if (!args[0]) return m.reply("> *\`『 اكتب الي بتبحث عليه معا الامر 🧚🏻‍♂️ 』\`*");

    const query = args.join(" ");
    try {
        const results = await google(query);

        if (results.length === 0) return m.reply("*\`『 الي بدور عليه مش موجود جرب ابحث تاني 』\`*");

        let caption = `🔍 *نتائج البحث عن: "${query}"*\n\n`;
        results.forEach((result, index) => {
            caption += `⭐ *${index + 1}. ${result.title}*\n`;
            caption += `🔗 *لينك*: ${result.link}\n`;
            caption += `📝 *الوصف*: ${result.description || "الوصف غير متوفر."}\n\n`;
        });

        const imageUrl = "https://files.catbox.moe/ggxx14.jpg"; 
        await conn.sendFile(m.chat, imageUrl, "result.jpg", caption.trim(), m);
    } catch (error) {
        console.error("Error:", error.message);
        m.reply("*\`『 حدث خطاء 』\`*");
    }
};

handler.help = handler.command = ['google','googlesearch','بحث', 'جوجل'];
handler.tags = ['tools'];
export default handler;

async function google(query) {
    try {
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        const response = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
            }
        });
        const html = response.data;
        const $ = cheerio.load(html);

        const results = [];
        $("div.tF2Cxc").each((index, element) => {
            const title = $(element).find("h3").text().trim();
            const link = $(element).find("a").attr("href");
            const description = $(element).find(".VwiC3b").text().trim();

            if (title && link) {
                results.push({ title, link, description });
            }
        });

        return results;
    } catch (error) {
        console.error("Error fetching search results:", error.message);
        throw new Error("Gagal mengambil data pencarian.");
    }
}