import fs from 'fs'
import path from 'path'
import { addExif } from '../lib/sticker.js'

let handler = async (m, { conn, text, isOwner }) => {
  if (!isOwner) throw '*\`『 هذا الأمر مخصص للمطور فقط 🧚🏻‍♂️ 』\`*'
  
  if (!m.quoted) throw '> *\`『 اعمل ريب ع الملصق🧚🏻‍♂️ 』\`*'
  
  let stiker = false
  try {
    if (!text) throw '> *\`『 اكتب الاسم الي عايزو ع الملصق 🤾‍♂️🥂 』\`*'
    
    let [packname, ...author] = text.split('|')
    author = (author || []).join('|')
    
    let mime = m.quoted.mimetype || ''
    if (!/webp/.test(mime)) throw '*قم بالرد على ملصق من نوع WEBP*'
    
    let img = await m.quoted.download()
    if (!img) throw '*\`『 خطاء🧸 』\`*'

    // التأكد من وجود المجلد `/tmp`
    const tmpDir = path.resolve('/home/container/tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

    // إضافة الحزمة للملصق
    stiker = await addExif(img, packname || '', author || '')

  } catch (e) {
    console.error(e)
    if (Buffer.isBuffer(e)) stiker = e
  } finally {
    if (stiker) {
      const tempPath = path.join('/home/container/tmp', `sticker_${Date.now()}.webp`)
      fs.writeFileSync(tempPath, stiker) // حفظ الملصق بشكل مؤقت

      await conn.sendFile(m.chat, tempPath, 'wm.webp', '', m, false, { asSticker: true })
      
      // حذف الملف المؤقت بعد الإرسال
      fs.unlinkSync(tempPath)
    } else {
      throw '> *\`『 اكتب الي عايز تسرق بي الملصق 🥂🤾‍♂️ 』\`*'
    }
  }
}

handler.help = ['wm <packname>|<author>']
handler.tags = ['sticker']
handler.command = /^سرقه|سرقة$/i
handler.owner = true // حصر الأمر على المطور فقط

export default handler