import {createHash} from 'crypto';
const Reg = /\|?(.*)([.|] *?)([0-9]*)$/i;

const handler = async function(m, {conn, text, usedPrefix, command}) {

  const user = global.db.data.users[m.sender];
  const name2 = conn.getName(m.sender);
  const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => global.img1);
  
  if (user.registered === true) return m.reply('انت مسجل');
  
  if (!Reg.test(text)) return m.reply(`مثال : ${usedPrefix + command} *safrot.20*`);
  
  let [_, name, splitter, age] = text.match(Reg);
  if (!name) return m.reply('الاسم');
  if (!age) return m.reply('السن');
  
  if (name.length >= 30) return m.reply('فرحان بطول اسمك');
  age = parseInt(age);
  
  if (age > 100) return m.reply('عجوز ي روح امك');
  if (age < 5) return m.reply('مبنلمش اطفال');
  
  user.name = name.trim();
  user.age = age;
  user.regTime = + new Date;
  user.registered = true;
  const sn = createHash('md5').update(m.sender).digest('hex');
  
  const caption = `
 الاسم : ${name}
 العمر : ${age}
 التوكن : ${sn}
`;

  
await conn.sendMessage(
  m.chat, { image: {url: pp}, caption: caption, footer: '© ' + wm,
    buttons: [
      {
        buttonId: '.اوامر',
        buttonText: {
          displayText: 'الاوامر',
        },
        type: 1, 
      },
      {
        buttonId: '.مطور',
        buttonText: {
          displayText: 'المطور',
        },
        type: 1, 
      },
    ], headerType: 1, viewOnce: true, }, { quoted: m });
  
  global.db.data.users[m.sender].money += 10000;
  global.db.data.users[m.sender].exp += 10000;
};
handler.help = ['verificar'];
handler.tags = ['xp'];
handler.command = ['تسجيل'];
export default handler;