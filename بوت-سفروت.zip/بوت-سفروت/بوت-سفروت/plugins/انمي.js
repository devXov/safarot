//بحقوك سفروت الكبير
import fetch from 'node-fetch';
import * as cheerio from 'cheerio';

const cookies = {
    time_zone: 'Asia/Jakarta',
    sitelang: 'ar',
    animepictures_gdpr: '{"choices":{"necessary":true,"tracking":true,"analytics":true,"marketing":true}}',
    _ga: 'GA1.1.2120781408.1735557636',
    aegentx: 'cookie709bc929fb31400f938c29a26bcb1c6d',
    _ga_CGRN7Q26LC: 'GS1.1.1735557636.1.1.1735558048.0.0.0'
};

async function searchAnimeImages(animeName, page = 0) {
    try {
        const url = `https://anime-pictures.net/posts?page=${page}&search_tag=${encodeURIComponent(animeName)}&lang=ar`;
        const response = await fetch(url, {
            headers: {
                'Cookie': Object.entries(cookies).map(([key, value]) => `${key}=${value}`).join('; ')
            }
        });
        const html = await response.text();
        const $ = cheerio.load(html);
        const imageUrls = [];
        $('picture.svelte-1ibbyvk').each((index, element) => {
            const dataSrc = $(element).attr('data-srcset');
            const imgSrc = $(element).find('img').attr('src');
            if (dataSrc || imgSrc) {
                const imageUrl = dataSrc ? dataSrc.split(',')[0].trim() : imgSrc;
                const fullImageUrl = imageUrl.startsWith('//') ? `https:${imageUrl}` : imageUrl;
                imageUrls.push(fullImageUrl);
            }
        });
        return imageUrls.length ? imageUrls : [];
    } catch (error) {
        console.error('خطأ:', error);
        return [];
    }
}

const handler = async (m, { conn, args }) => {
    try {
        if (args.length === 0) {
            return conn.sendMessage(m.chat, {
                text: '`مثال`\n\n- انمي قائمة\n- انمي اسم_الأنمي'
            }, {
                quoted: m
            });
        }

        if (args[0] === 'قائمة') {
            const animeList = [
                'Naruto',
                'One Piece',
                'Attack on Titan',
                'My Hero Academia',
                'Demon Slayer',
                'Death Note',
                'Jujutsu Kaisen',
                'Sword Art Online',
                'Bleach',
                'Tokyo Ghoul'
            ];
            return conn.sendMessage(m.chat, {
                text: `⚇━━━━━━❰･𓃦･❱━━━━━━⚇\n\n*\`『 منيو الانمي 』\`*\n\n${animeList.map((anime, i) => `${i + 1}. ${anime}`).join('\n')}\n\nاكتب:\n- انمي اسم_الأنمي للحصول على الصور\n\n⚇━━━━━━❰･𓃦･❱━━━━━━⚇`
            }, {
                quoted: m
            });
        } else {
            const animeName = args.join(' ');
            const images = await searchAnimeImages(animeName);
            if (images.length === 0) {
                return conn.sendMessage(m.chat, {
                    text: `⚠️ لم يتم العثور على صور لأنمي "${animeName}".`
                }, {
                    quoted: m
                });
            }
            for (const img of images.slice(0, 5)) {
                await conn.sendMessage(m.chat, {
                    image: {
                        url: img
                    },
                    caption: `📷 صورة لأنمي "${animeName}"`
                }, {
                    quoted: m
                });
            }
        }
    } catch (error) {
        console.error(error);
        return conn.sendMessage(m.chat, {
            text: `${error.message}`
        }, {
            quoted: m
        });
    }
};

handler.command = ['انمي'];
handler.tags = ['أنمي'];
handler.help = ['انمي قائمة', 'انمي اسم_الأنمي'];
handler.limit = true;

export default handler;